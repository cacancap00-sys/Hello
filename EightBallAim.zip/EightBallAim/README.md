# 8 Pool Aim

Đường ngắm mảnh hiển thị trực tiếp trên game 8 Ball Pool (overlay), tự nhận diện bàn và bi.

## Lấy file APK

**Cách 1 – GitHub (không cần cài gì):**
1. Tạo repo GitHub, đẩy toàn bộ thư mục này lên.
2. Vào tab **Actions** → chạy "Build APK" → tải `8pool-aim-apk` → giải nén ra `app-debug.apk`.

**Cách 2 – Android Studio:** mở thư mục này → *Build > Build APK(s)* →
`app/build/outputs/apk/debug/app-debug.apk`.

Cài APK vào điện thoại (cho phép cài từ nguồn ngoài).

## Dùng
1. Mở app → **Bắt đầu** → cấp quyền *Hiển thị trên ứng dụng khác* và *Ghi màn hình*.
2. Mở 8 Ball Pool, xoay ngang. Đường ngắm hiện tự động.
3. `◎ Chọn bi`: chạm vào bi muốn đánh. `Lỗ/Tâm`: ngắm vào lỗ hoặc vào tâm bi.

## Tinh chỉnh (nếu lệch)
- `Detector.java`: `r0 = t.width() / 80.0` là tỉ lệ bán kính bi so với chiều dài bàn.
  Nếu app không thấy bi hoặc nhận thừa, chỉnh số 80 (70–95).
- `Detector.java` → `buildFelt()`: ngưỡng màu nỉ (16°, 0.30, 0.32) nếu bạn dùng bàn có màu khác.
- `ShotPlanner.java`: vị trí lỗ (`pockets`) và hệ số co băng (`xl, xr, yt, yb`).

## Kiểm thử phần lõi (không cần Android)
```
javac -d out app/src/main/java/com/aimassist/pool/core/*.java tools/CoreTest.java
java -cp out CoreTest
```
