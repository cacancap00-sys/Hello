import com.aimassist.pool.core.*;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/** Chạy thử phần lõi trên ảnh bàn giả lập (không cần Android). */
public class CoreTest {
    static final int W = 800, H = 400;
    static int[] px = new int[W * H];

    static void set(int x, int y, int rgb) {
        if (x >= 0 && y >= 0 && x < W && y < H) px[y * W + x] = rgb;
    }

    static int hsv(float h, float s, float v) {
        return Color.HSBtoRGB(h / 360f, s, v) & 0xffffff;
    }

    static void disc(double cx, double cy, double r, int rgb) {
        for (int y = (int) (cy - r - 1); y <= cy + r + 1; y++)
            for (int x = (int) (cx - r - 1); x <= cx + r + 1; x++)
                if (Math.hypot(x + 0.5 - cx, y + 0.5 - cy) <= r) set(x, y, rgb);
    }

    static void ball(double cx, double cy, double r, int rgb, boolean white) {
        disc(cx, cy, r, rgb);
        if (!white) disc(cx - r * 0.25, cy - r * 0.25, r * 0.28, 0xf0f0f0); // chấm số
        else disc(cx - r * 0.3, cy - r * 0.3, r * 0.2, 0xffffff);
    }

    public static void main(String[] a) {
        // Nền + thanh chắn
        for (int i = 0; i < px.length; i++) px[i] = 0x202428;
        for (int y = 30; y < 370; y++) for (int x = 60; x < 740; x++) set(x, y, 0x5a3a1e); // băng gỗ
        for (int y = 50; y < 350; y++) {
            for (int x = 80; x < 720; x++) {
                // nỉ xanh dương, sáng dần ở giữa (vignette)
                double dx = (x - 400) / 320.0, dy = (y - 200) / 150.0;
                float v = (float) (0.62 - 0.12 * (dx * dx + dy * dy));
                set(x, y, hsv(200, 0.78f, v));
            }
        }
        // Lỗ
        double[][] pk = {{80, 50}, {720, 50}, {80, 350}, {720, 350}, {400, 50}, {400, 350}};
        for (double[] p : pk) disc(p[0], p[1], 13, 0x050505);

        double r = 8; // 640/80
        double[][] truth = {
                {200, 200},  // bi cái
                {400, 180},  // đỏ (mục tiêu)
                {416, 180},  // tím, dính bi đỏ
                {450, 250},  // vàng
                {300, 120},  // xanh
                {600, 300},  // bi 8 (đen)
                {520, 100},  // xanh lá
                {330, 290},  // cam
        };
        int[] colors = {0xffffff, 0xd02020, 0x7030a0, 0xe0c020, 0x2040c0, 0x101010, 0x20a030, 0xe07020};

        // Cây cơ dính bi cái + đường ngắm mảnh của game
        for (int y = 198; y < 202; y++) for (int x = 92; x < 192; x++) set(x, y, 0xb08040);

        for (int i = 0; i < truth.length; i++) ball(truth[i][0], truth[i][1], r, colors[i], i == 0);

        Engine eng = new Engine();
        Scene s = null;
        for (int f = 0; f < 4; f++) s = eng.process(px.clone(), W, H);

        System.out.printf("Bàn: l=%.1f t=%.1f r=%.1f b=%.1f (thật 80/50/720/350)%n",
                s.table.l, s.table.t, s.table.r, s.table.b);
        System.out.printf("Bán kính bi ước lượng: %.2f (thật %.1f)%n", s.r, r);
        System.out.println("Số bi nhận diện: " + s.balls.size() + " (thật " + truth.length + ")");
        double worst = 0;
        int matched = 0;
        for (double[] t : truth) {
            Ball nb = null;
            double bd = 1e9;
            for (Ball b : s.balls) {
                double d = Math.hypot(b.x - t[0], b.y - t[1]);
                if (d < bd) { bd = d; nb = b; }
            }
            if (nb != null && bd < 3) matched++;
            worst = Math.max(worst, bd);
            System.out.printf("  thật (%.0f,%.0f) -> (%.2f,%.2f) lệch %.2f px%n", t[0], t[1],
                    nb == null ? -1 : nb.x, nb == null ? -1 : nb.y, bd);
        }
        System.out.printf("Khớp %d/%d, lệch lớn nhất %.2f px (ảnh %dpx rộng)%n", matched, truth.length, worst, W);
        Ball cue = null;
        for (Ball b : s.balls) if (b.id == s.cueId) cue = b;
        System.out.println("Bi cái: " + (cue == null ? "KHÔNG THẤY" : String.format("(%.1f,%.1f)", cue.x, cue.y)));

        ShotPlanner.Plan p = s.plan;
        if (p == null) {
            System.out.println("Không có kế hoạch cú đánh!");
            return;
        }
        System.out.printf("Mục tiêu tự chọn id=%d, bank=%b, pocket=%b, score=%.1f%n",
                s.targetId, p.bank, p.pocketShot, p.score);
        System.out.printf("Bi ma: (%.1f,%.1f)  tốc độ bi mục tiêu=%.2f  bi cái=%.2f%n",
                p.gx, p.gy, p.targetSpeed, p.cueSpeed);
        String[] nm = {"NGẮM", "BI MỤC TIÊU", "BI CÁI SAU VA CHẠM"};
        for (ShotPlanner.Poly pl : p.polys) {
            StringBuilder sb = new StringBuilder(nm[pl.kind] + ": ");
            for (int i = 0; i < pl.xy.length; i += 2) sb.append(String.format("(%.1f,%.1f) ", pl.xy[i], pl.xy[i + 1]));
            System.out.println(sb);
        }

        // --- Kiểm tra vật lý: va chạm đàn hồi, bi mục tiêu đi theo đường nối tâm
        Ball tg = null;
        for (Ball b : s.balls) if (b.id == s.targetId) tg = b;
        double nx = tg.x - p.gx, ny = tg.y - p.gy, nl = Math.hypot(nx, ny);
        System.out.printf("Khoảng cách tâm bi ma - bi mục tiêu = %.2f (kỳ vọng %.2f)%n", nl, 2 * s.r);
        for (ShotPlanner.Poly pl : p.polys) {
            if (pl.kind == ShotPlanner.TARGET) {
                double dx = pl.xy[2] - pl.xy[0], dy = pl.xy[3] - pl.xy[1], l = Math.hypot(dx, dy);
                System.out.printf("Hướng bi mục tiêu vs đường nối tâm: tích vô hướng = %.4f (kỳ vọng 1)%n",
                        (dx * nx + dy * ny) / (l * nl));
            }
            if (pl.kind == ShotPlanner.CUE) {
                double dx = pl.xy[2] - pl.xy[0], dy = pl.xy[3] - pl.xy[1], l = Math.hypot(dx, dy);
                System.out.printf("Hướng bi cái sau va chạm vuông góc đường nối tâm: |cos| = %.4f (kỳ vọng 0)%n",
                        Math.abs((dx * nx + dy * ny) / (l * nl)));
            }
        }

        // --- Chọn thủ công bi vàng bằng chạm + chế độ đánh tâm
        Scene s2 = eng.select(450, 250);
        System.out.printf("Chọn tay bi vàng: manual=%b target=%d bank=%b pocket=%b%n",
                s2.manual, s2.targetId, s2.plan.bank, s2.plan.pocketShot);
        eng.setCenterMode(true);
        Scene s3 = eng.process(px.clone(), W, H);
        System.out.printf("Đánh tâm: pocket=%b, số đường=%d%n", s3.plan.pocketShot, s3.plan.polys.size());

        // --- Kiểm tra chịu nhiễu: nhiễu ảnh + đường ngắm của chính app vẽ chồng lên bi
        int[] px2 = px.clone();
        java.util.Random rnd = new java.util.Random(7);
        for (int i = 0; i < px2.length; i++) {
            int c = px2[i];
            int rr = Math.max(0, Math.min(255, ((c >> 16) & 255) + (int) (rnd.nextGaussian() * 5)));
            int gg = Math.max(0, Math.min(255, ((c >> 8) & 255) + (int) (rnd.nextGaussian() * 5)));
            int bb = Math.max(0, Math.min(255, (c & 255) + (int) (rnd.nextGaussian() * 5)));
            px2[i] = (rr << 16) | (gg << 8) | bb;
        }
        // đường mảnh 1px bán trong suốt đi xuyên qua nhiều bi (mô phỏng overlay bị chụp lại)
        for (double[] seg : new double[][]{{200, 200, 400, 180}, {400, 180, 600, 300}, {300, 120, 450, 250}}) {
            for (int k = 0; k <= 400; k++) {
                int x = (int) (seg[0] + (seg[2] - seg[0]) * k / 400.0);
                int y = (int) (seg[1] + (seg[3] - seg[1]) * k / 400.0);
                int c = px2[y * W + x];
                int rr = ((c >> 16) & 255) * 3 / 10 + 255 * 7 / 10;
                int gg = ((c >> 8) & 255) * 3 / 10 + 255 * 7 / 10;
                int bb = (c & 255) * 3 / 10 + 255 * 7 / 10;
                px2[y * W + x] = (rr << 16) | (gg << 8) | bb;
            }
        }
        Engine e2 = new Engine();
        Scene sn = null;
        for (int f = 0; f < 4; f++) sn = e2.process(px2.clone(), W, H);
        int m2 = 0;
        double w2 = 0;
        for (double[] t : truth) {
            double bd = 1e9;
            for (Ball b : sn.balls) bd = Math.min(bd, Math.hypot(b.x - t[0], b.y - t[1]));
            if (bd < 3) m2++;
            w2 = Math.max(w2, bd);
        }
        System.out.printf("Có nhiễu + đường chồng: %d/%d bi khớp, bi dư=%d, lệch lớn nhất %.2f px, bi cái %s%n",
                m2, truth.length, sn.balls.size() - m2, w2, sn.cueId >= 0 ? "thấy" : "KHÔNG thấy");

        // --- Kiểm tra ăn băng trước: chặn đường thẳng tới bi mục tiêu bằng 1 bi
        List<Ball> bl = new ArrayList<>();
        Ball c = new Ball(); c.id = 1; c.x = 200; c.y = 200; c.white = 1;
        Ball t2 = new Ball(); t2.id = 2; t2.x = 500; t2.y = 200;
        Ball blk = new Ball(); blk.id = 3; blk.x = 350; blk.y = 200;
        bl.add(c); bl.add(t2); bl.add(blk);
        ShotPlanner sp = new ShotPlanner(s.table, s.r, bl);
        ShotPlanner.Plan bp = sp.plan(c, t2, true);
        System.out.printf("Bị chắn thẳng -> ăn băng: bank=%b, số đường=%d%n", bp.bank, bp.polys.size());
        double[] xy = bp.polys.get(0).xy;
        StringBuilder sb = new StringBuilder("  đường ngắm: ");
        for (int i = 0; i < xy.length; i += 2) sb.append(String.format("(%.1f,%.1f) ", xy[i], xy[i + 1]));
        System.out.println(sb);
    }
}
