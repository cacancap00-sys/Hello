import com.aimassist.pool.core.*;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Arrays;

/** java VideoTest <thư mục khung> <thư mục ra> : chạy Engine tuần tự qua các khung, xuất log + ảnh debug. */
public class VideoTest {
    static int[] toProc(BufferedImage src) {
        // Giả lập app: màn hình -> 1230 rộng (virtual display) -> lấy mẫu 2x2 xuống 800.
        int W = 1230, H = Math.round(src.getHeight() * 1230f / src.getWidth());
        BufferedImage mid = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = mid.createGraphics();
        g.drawImage(src.getScaledInstance(W, H, Image.SCALE_AREA_AVERAGING), 0, 0, null);
        g.dispose();
        int pw = 800, ph = Math.round(H * (pw / (float) W));
        int[] out = new int[pw * ph];
        for (int y = 0; y < ph; y++) {
            int y0 = Math.min(H - 1, (int) (y * (float) H / ph + 0.25f * H / ph));
            int y1 = Math.min(H - 1, (int) (y * (float) H / ph + 0.75f * H / ph));
            for (int x = 0; x < pw; x++) {
                int x0 = Math.min(W - 1, (int) (x * (float) W / pw + 0.25f * W / pw));
                int x1 = Math.min(W - 1, (int) (x * (float) W / pw + 0.75f * W / pw));
                int[] c = {mid.getRGB(x0, y0), mid.getRGB(x1, y0), mid.getRGB(x0, y1), mid.getRGB(x1, y1)};
                int r = 0, gg = 0, b = 0;
                for (int v : c) { r += (v >> 16) & 255; gg += (v >> 8) & 255; b += v & 255; }
                out[y * pw + x] = ((r >> 2) << 16) | ((gg >> 2) << 8) | (b >> 2);
            }
        }
        return out;
    }

    public static void main(String[] a) throws Exception {
        File[] fs = new File(a[0]).listFiles((d, n) -> n.endsWith(".jpg"));
        Arrays.sort(fs);
        new File(a[1]).mkdirs();
        Engine eng = new Engine();
        int step = a.length > 2 ? Integer.parseInt(a[2]) : 2; // app ~15fps: lấy cách 1-2 khung
        for (int i = 0; i < fs.length; i += step) {
            BufferedImage src = ImageIO.read(fs[i]);
            int[] px = toProc(src);
            int pw = 800, ph = px.length / pw;
            long t0 = System.nanoTime();
            Scene s = eng.process(px.clone(), pw, ph);
            double ms = (System.nanoTime() - t0) / 1e6;
            String tag = String.format("f%03d", i + 1);
            int nb = s.balls.size();
            StringBuilder sb = new StringBuilder(tag + String.format(" %.0fms", ms) + " bi=" + nb);
            Ball cue = null;
            for (Ball b : s.balls) if (b.id == s.cueId) cue = b;
            sb.append(cue == null ? " CÁI=KHÔNG" : String.format(" cái=(%.0f,%.0f)", cue.x, cue.y));
            if (s.plan == null) sb.append(" plan=KHÔNG");
            else sb.append(String.format(" plan follow=%b target=%d bank=%b ghost=%s npoly=%d",
                    s.plan.followGame, s.targetId, s.plan.bank,
                    Double.isNaN(s.plan.gx) ? "-" : String.format("(%.0f,%.0f)", s.plan.gx, s.plan.gy), s.plan.polys.size()));
            System.out.println(sb);
            // ảnh debug
            BufferedImage dbg = new BufferedImage(pw, ph, BufferedImage.TYPE_INT_RGB);
            dbg.setRGB(0, 0, pw, ph, px, 0, pw);
            Graphics2D d = dbg.createGraphics();
            d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            if (s.table != null) {
                d.setColor(Color.YELLOW);
                d.drawRect((int) s.table.l, (int) s.table.t, (int) s.table.width(), (int) s.table.height());
                for (Ball b : s.balls) {
                    d.setColor(b.id == s.cueId ? Color.RED : Color.MAGENTA);
                    d.drawOval((int) (b.x - s.r), (int) (b.y - s.r), (int) (2 * s.r), (int) (2 * s.r));
                }
                if (s.plan != null) {
                    for (ShotPlanner.Poly p : s.plan.polys) {
                        d.setColor(p.kind == 0 ? Color.GREEN : p.kind == 1 ? Color.ORANGE : Color.CYAN);
                        for (int k = 2; k < p.xy.length; k += 2)
                            d.drawLine((int) p.xy[k - 2], (int) p.xy[k - 1], (int) p.xy[k], (int) p.xy[k + 1]);
                    }
                    if (!Double.isNaN(s.plan.gx)) {
                        d.setColor(Color.GREEN);
                        d.drawOval((int) (s.plan.gx - s.r), (int) (s.plan.gy - s.r), (int) (2 * s.r), (int) (2 * s.r));
                    }
                }
            }
            ImageIO.write(dbg, "png", new File(a[1], tag + ".png"));
        }
    }
}
