import com.aimassist.pool.core.*;
import java.awt.Color;

/** Xoay đường ngắm trắng quanh bi cái, kiểm tra app bám theo đúng góc và tính bi ma/băng. */
public class AimTrackTest {
    static final int W = 800, H = 400;

    public static void main(String[] a) {
        double worst = 0;
        int ok = 0, n = 0;
        for (int deg = -170; deg <= 170; deg += 10) {
            int[] px = new int[W * H];
            for (int i = 0; i < px.length; i++) px[i] = 0x202428;
            for (int y = 50; y < 350; y++) for (int x = 80; x < 720; x++) {
                double dx = (x - 400) / 320.0, dy = (y - 200) / 150.0;
                px[y * W + x] = Color.HSBtoRGB(200 / 360f, 0.78f, (float) (0.62 - 0.12 * (dx * dx + dy * dy))) & 0xffffff;
            }
            double cx = 400, cy = 200, r = 8;
            disc(px, cx, cy, r, 0xffffff);
            double[][] others = {{520, 150}, {300, 260}, {450, 300}};
            int[] col = {0x2040c0, 0xd02020, 0xe0c020};
            for (int i = 0; i < others.length; i++) disc(px, others[i][0], others[i][1], r, col[i]);
            double ang = Math.toRadians(deg);
            for (double t = r + 2; t < 170; t += 0.5) {
                int x = (int) (cx + Math.cos(ang) * t), y = (int) (cy + Math.sin(ang) * t);
                if (x > 0 && y > 0 && x < W && y < H) px[y * W + x] = 0xffffff;
            }
            Detector det = new Detector();
            Detector.Result res = det.detect(px, W, H);
            Ball cue = null;
            for (Ball b : res.balls) if (Math.hypot(b.x - cx, b.y - cy) < 2) cue = b;
            n++;
            if (cue == null) { System.out.println(deg + "°: không thấy bi cái"); continue; }
            double[] aim = det.findAim(cue.x, cue.y, res.radius);
            if (aim == null) { System.out.println(deg + "°: không thấy đường ngắm"); continue; }
            double got = Math.toDegrees(Math.atan2(aim[1], aim[0]));
            double err = Math.abs(((got - deg) + 540) % 360 - 180);
            worst = Math.max(worst, err);
            if (err < 0.5) ok++;
        }
        System.out.printf("Xoay đường ngắm 36 góc: %d/%d đúng (<0.5°), lệch lớn nhất %.2f°%n", ok, n, worst);

        // Ngắm thẳng vào bi đỏ (520,150): kiểm tra bi ma, hướng bi mục tiêu và bi cái sau va chạm.
        Ball cue = new Ball(); cue.id = 1; cue.x = 400; cue.y = 200; cue.white = 1;
        Ball t = new Ball(); t.id = 2; t.x = 520; t.y = 150;
        java.util.List<Ball> bl = new java.util.ArrayList<>();
        bl.add(cue); bl.add(t);
        ShotPlanner sp = new ShotPlanner(new Table(80, 50, 720, 350), 8, bl);
        double ang = Math.atan2(150 - 200 + 8, 520 - 400); // lệch nhẹ: cắt mỏng bi
        ShotPlanner.Plan p = sp.planDirection(cue, Math.cos(ang), Math.sin(ang));
        System.out.printf("Cắt mỏng: bi ma=(%.1f,%.1f) tốc độ bi mục tiêu=%.2f, bi cái=%.2f%n",
                p.gx, p.gy, p.targetSpeed, p.cueSpeed);
        // Ngắm vào băng trên rồi dội vào bi
        ang = Math.atan2(-1, 0.55);
        p = sp.planDirection(cue, Math.cos(ang), Math.sin(ang));
        System.out.printf("Ngắm lên băng: bank=%b, số đường=%d, có bi ma=%b%n", p.bank, p.polys.size(), !Double.isNaN(p.gx));
    }

    static void disc(int[] px, double cx, double cy, double r, int rgb) {
        for (int y = (int) (cy - r - 1); y <= cy + r + 1; y++)
            for (int x = (int) (cx - r - 1); x <= cx + r + 1; x++)
                if (Math.hypot(x + 0.5 - cx, y + 0.5 - cy) <= r) px[y * W + x] = rgb;
    }
}
