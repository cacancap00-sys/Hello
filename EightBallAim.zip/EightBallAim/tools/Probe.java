import com.aimassist.pool.core.*;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Arrays;

public class Probe {
    public static void main(String[] a) throws Exception {
        File[] fs = new File(a[0]).listFiles((d, n) -> n.endsWith(".jpg"));
        Arrays.sort(fs);
        Detector det = new Detector();
        for (int i = 0; i < fs.length; i += Integer.parseInt(a[1])) {
            int[] px = VideoTest.toProc(ImageIO.read(fs[i]));
            Detector.Result res = det.detect(px, 800, px.length / 800);
            Ball cue = null;
            for (Ball b : res.balls) if (cue == null || b.white > cue.white) cue = b;
            if (cue == null) { System.out.printf("f%03d không có bi%n", i + 1); continue; }
            double r = res.radius;
            StringBuilder sb = new StringBuilder(String.format("f%03d r=%.1f cue=(%.0f,%.0f) T=[%.0f,%.0f,%.0f,%.0f]", i + 1, r, cue.x, cue.y,
                    res.table.l, res.table.t, res.table.r, res.table.b));
            double[] ln = det.findAim(cue.x, cue.y, r);
            double ux = 0, uy = 0;
            if (ln != null) {
                ux = ln[0]; uy = ln[1];
                sb.append(String.format(" LINE ang=%.1f len=%.0f end=%.0f", Math.toDegrees(Math.atan2(uy, ux)), ln[2], ln[3]));
                double[] rg = det.findRingAlong(cue.x, cue.y, ux, uy, r, Math.max(0, ln[3] - 3 * r), ln[3] + 2 * r);
                if (rg != null) {
                    double d = Math.hypot(rg[0] - cue.x, rg[1] - cue.y);
                    sb.append(String.format(" RING=(%.1f,%.1f) s=%.2f d=%.0f angRing=%.1f", rg[0], rg[1], rg[2], d,
                            Math.toDegrees(Math.atan2(rg[1] - cue.y, rg[0] - cue.x))));
                } else sb.append(" RING=không");
            } else {
                double[] rn = det.findRingNear(cue.x, cue.y, r);
                sb.append(rn == null ? " LINE=không RINGNEAR=không" : String.format(" LINE=không RINGNEAR=(%.1f,%.1f) s=%.2f d=%.1f ang=%.1f",
                        rn[0], rn[1], rn[2], Math.hypot(rn[0] - cue.x, rn[1] - cue.y), Math.toDegrees(Math.atan2(rn[1] - cue.y, rn[0] - cue.x))));
            }
            System.out.println(sb);
        }
    }
}
