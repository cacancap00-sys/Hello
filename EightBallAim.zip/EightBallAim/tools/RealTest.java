import com.aimassist.pool.core.*;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

/** Chạy lõi trên ảnh chụp thật: java RealTest in.jpg out.png */
public class RealTest {
    public static void main(String[] a) throws Exception {
        BufferedImage src = ImageIO.read(new File(a[0]));
        int W = 800, H = Math.round(src.getHeight() * 800f / src.getWidth());
        BufferedImage sm = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = sm.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.drawImage(src, 0, 0, W, H, null);
        int[] px = sm.getRGB(0, 0, W, H, null, 0, W);

        Engine eng = new Engine();
        Scene s = null;
        for (int i = 0; i < 4; i++) s = eng.process(px.clone(), W, H);

        System.out.println("ảnh " + W + "x" + H);
        if (s.table == null) {
            System.out.println("KHÔNG TÌM THẤY BÀN");
        } else {
            System.out.printf("bàn l=%.0f t=%.0f r=%.0f b=%.0f  bán kính bi=%.2f  số bi=%d  bi cái id=%d%n",
                    s.table.l, s.table.t, s.table.r, s.table.b, s.r, s.balls.size(), s.cueId);
        }
        Graphics2D d = sm.createGraphics();
        d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        if (s.table != null) {
            d.setColor(Color.YELLOW);
            d.drawRect((int) s.table.l, (int) s.table.t, (int) s.table.width(), (int) s.table.height());
            for (Ball b : s.balls) {
                d.setColor(b.id == s.cueId ? Color.RED : Color.MAGENTA);
                d.drawOval((int) (b.x - s.r), (int) (b.y - s.r), (int) (2 * s.r), (int) (2 * s.r));
                System.out.printf("  bi id=%d (%.1f,%.1f) white=%.2f v=%.2f%n", b.id, b.x, b.y, b.white, b.meanV);
            }
            if (s.plan != null) {
                System.out.printf("PLAN followGame=%b target=%d bank=%b ghost=(%.1f,%.1f) vTarget=%.2f vCue=%.2f%n",
                        s.plan.followGame, s.targetId, s.plan.bank, s.plan.gx, s.plan.gy, s.plan.targetSpeed, s.plan.cueSpeed);
                for (ShotPlanner.Poly q : s.plan.polys) {
                    StringBuilder sb = new StringBuilder("  kind" + q.kind + ":");
                    for (int i = 0; i < q.xy.length; i += 2) sb.append(String.format(" (%.1f,%.1f)", q.xy[i], q.xy[i + 1]));
                    System.out.println(sb);
                }
                for (ShotPlanner.Poly p : s.plan.polys) {
                    d.setColor(p.kind == 0 ? Color.GREEN : p.kind == 1 ? Color.ORANGE : Color.CYAN);
                    for (int i = 2; i < p.xy.length; i += 2)
                        d.drawLine((int) p.xy[i - 2], (int) p.xy[i - 1], (int) p.xy[i], (int) p.xy[i + 1]);
                }
            }
        }
        ImageIO.write(sm, "png", new File(a[1]));
    }
}
