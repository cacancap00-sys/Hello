package com.aimassist.pool;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_OVERLAY = 1, REQ_CAPTURE = 2, REQ_NOTIF = 3;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        int pad = Math.round(24 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView t = new TextView(this);
        t.setTextSize(15);
        t.setText("8 Pool Aim\n\n"
                + "1. Bấm Bắt đầu, cấp quyền hiển thị trên ứng dụng khác và cho phép ghi màn hình.\n"
                + "2. Mở game 8 Ball Pool, xoay ngang.\n"
                + "3. Đường ngắm mảnh tự hiện trên bàn: từ bi cái tới bi mục tiêu, kèm hướng bi sau va chạm "
                + "và đường dội băng.\n"
                + "4. Nút \"◎ Chọn bi\": chạm vào bi muốn đánh (mặc định app tự chọn bi dễ nhất).\n"
                + "5. Nút \"Lỗ/Tâm\": đổi giữa ngắm vào lỗ và ngắm vào tâm bi.\n\n"
                + "Tắt: nút ✕ trên bảng nhỏ hoặc nút Tắt trong thông báo.");
        root.addView(t);

        Button go = new Button(this);
        go.setText("Bắt đầu");
        go.setOnClickListener(v -> start());
        root.addView(go);
        setContentView(root);
    }

    private void start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Bật \"Hiển thị trên ứng dụng khác\" rồi quay lại bấm Bắt đầu", Toast.LENGTH_LONG).show();
            startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())), REQ_OVERLAY);
            return;
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
            return;
        }
        MediaProjectionManager mpm = getSystemService(MediaProjectionManager.class);
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] p, int[] r) {
        super.onRequestPermissionsResult(code, p, r);
        if (code == REQ_NOTIF) start(); // dù từ chối thông báo vẫn chạy tiếp
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_CAPTURE) {
            if (res != RESULT_OK || data == null) {
                Toast.makeText(this, "Cần cho phép ghi màn hình", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent svc = new Intent(this, CaptureService.class);
            svc.putExtra(CaptureService.EXTRA_CODE, res);
            svc.putExtra(CaptureService.EXTRA_DATA, data);
            startForegroundService(svc);
            Toast.makeText(this, "Đã bật. Mở 8 Ball Pool và xoay ngang.", Toast.LENGTH_LONG).show();
            moveTaskToBack(true);
        }
    }
}
