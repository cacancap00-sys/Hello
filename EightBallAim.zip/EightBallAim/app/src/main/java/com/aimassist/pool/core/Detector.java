package com.aimassist.pool.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Nhận diện bàn (màu nỉ chiếm ưu thế) và bi (biến đổi khoảng cách trên vùng không phải nỉ).
 * Dùng distance transform nên vẫn tách được bi dính nhau và bi dính cây cơ / vạch ngắm của game.
 */
public final class Detector {

    public static final class Result {
        public Table table;
        public double radius;
        public final List<Ball> balls = new ArrayList<>();
    }

    private static final class Peak {
        int x, y, d;
        boolean valid;
    }

    private int w, h;
    private float[] H, S, V;
    private boolean[] felt;
    private Table table;
    private double fh = -1, fs, fv;
    private int frameNo;

    public synchronized void reset() {
        table = null;
        fh = -1;
        frameNo = 0;
    }

    public synchronized Result detect(int[] px, int w, int h) {
        this.w = w;
        this.h = h;
        hsv(px);
        Result res = new Result();
        boolean built = false;
        if (table == null || frameNo % 24 == 0) {
            Table t = findTable();
            if (t != null) {
                built = true;
                // Giữ nguyên bàn cũ nếu lệch < 2px để đường ngắm không rung.
                if (table == null || !close(table, t, 2.0)) table = t;
            } else if (table == null) {
                frameNo++;
                return res;
            }
        }
        if (!built) buildFelt();
        frameNo++;
        res.table = table;
        detectBalls(res);
        return res;
    }

    private static boolean close(Table a, Table b, double tol) {
        return Math.abs(a.l - b.l) < tol && Math.abs(a.t - b.t) < tol
                && Math.abs(a.r - b.r) < tol && Math.abs(a.b - b.b) < tol;
    }

    // ---------------------------------------------------------------- màu

    private void hsv(int[] px) {
        int n = w * h;
        if (H == null || H.length != n) {
            H = new float[n];
            S = new float[n];
            V = new float[n];
            felt = new boolean[n];
        }
        for (int i = 0; i < n; i++) {
            int c = px[i];
            int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
            int mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b));
            float d = mx - mn;
            V[i] = mx / 255f;
            S[i] = mx == 0 ? 0 : d / mx;
            float hh;
            if (d == 0) hh = 0;
            else if (mx == r) hh = 60f * (((g - b) / d) % 6f);
            else if (mx == g) hh = 60f * ((b - r) / d + 2f);
            else hh = 60f * ((r - g) / d + 4f);
            if (hh < 0) hh += 360f;
            H[i] = hh;
        }
    }

    private static float hdist(float a, double b) {
        float d = (float) Math.abs(a - b);
        return d > 180f ? 360f - d : d;
    }

    private void buildFelt() {
        int n = w * h;
        for (int i = 0; i < n; i++) {
            // Hue chặt (12 độ) để bi xanh dương không bị nhầm thành nỉ xanh lơ.
            felt[i] = hdist(H[i], fh) < 12f
                    && Math.abs(S[i] - fs) < 0.34
                    && Math.abs(V[i] - fv) < 0.36;
        }
    }

    // ---------------------------------------------------------------- bàn

    private Table findTable() {
        int n = w * h;
        double[] hist = new double[36];
        for (int i = 0; i < n; i++) {
            if (S[i] > 0.35f && V[i] > 0.25f) hist[((int) (H[i] / 10f)) % 36]++;
        }
        int pk = -1;
        double best = 0;
        for (int b = 0; b < 36; b++) {
            double c = hist[(b + 35) % 36] + hist[b] + hist[(b + 1) % 36];
            if (c > best) {
                best = c;
                pk = b;
            }
        }
        if (pk < 0 || best < n * 0.04) return null;
        double centre = pk * 10 + 5;
        double sx = 0, sy = 0, ss = 0, sv = 0, cnt = 0;
        for (int i = 0; i < n; i++) {
            if (S[i] > 0.35f && V[i] > 0.25f && hdist(H[i], centre) <= 15f) {
                double rad = Math.toRadians(H[i]);
                sx += Math.cos(rad);
                sy += Math.sin(rad);
                ss += S[i];
                sv += V[i];
                cnt++;
            }
        }
        if (cnt < 1) return null;
        double nh = Math.toDegrees(Math.atan2(sy, sx));
        if (nh < 0) nh += 360;
        double oh = fh, os = fs, ov = fv;
        fh = nh;
        fs = ss / cnt;
        fv = sv / cnt;
        buildFelt();
        Table t = bbox();
        if (t == null) {
            fh = oh;
            fs = os;
            fv = ov;
            return null;
        }
        return t;
    }

    private Table bbox() {
        int[] rows = new int[h], cols = new int[w];
        for (int y = 0; y < h; y++) {
            int base = y * w;
            for (int x = 0; x < w; x++) {
                if (felt[base + x]) {
                    rows[y]++;
                    cols[x]++;
                }
            }
        }
        int maxR = 0, maxC = 0;
        for (int v : rows) maxR = Math.max(maxR, v);
        for (int v : cols) maxC = Math.max(maxC, v);
        if (maxR == 0 || maxC == 0) return null;
        int top = -1, bot = -1, left = -1, right = -1;
        for (int y = 0; y < h; y++) {
            if (rows[y] >= 0.45 * maxR) {
                if (top < 0) top = y;
                bot = y;
            }
        }
        for (int x = 0; x < w; x++) {
            if (cols[x] >= 0.45 * maxC) {
                if (left < 0) left = x;
                right = x;
            }
        }
        if (top < 0 || left < 0) return null;
        double tw = right + 1 - left, th = bot + 1 - top;
        if (tw < 0.3 * w || th < 10) return null;
        double ratio = tw / th;
        if (ratio < 1.5 || ratio > 2.6) return null;
        return new Table(left, top, right + 1, bot + 1);
    }

    // ----------------------------------------------------------------- bi

    private void detectBalls(Result res) {
        Table t = table;
        int L = (int) Math.ceil(t.l), T = (int) Math.ceil(t.t);
        int R = (int) Math.floor(t.r) - 1, B = (int) Math.floor(t.b) - 1;
        int rw = R - L + 1, rh = B - T + 1;
        if (rw < 20 || rh < 10) return;
        int pw = rw + 2, ph = rh + 2;

        byte[] m = new byte[pw * ph];
        for (int y = T; y <= B; y++) {
            int src = y * w, dst = (y - T + 1) * pw + 1;
            for (int x = L; x <= R; x++) {
                m[dst + x - L] = (byte) (felt[src + x] ? 0 : 1);
            }
        }
        // Mở ảnh 3x3: xoá đường ngắm mảnh (của game và của app) và nhiễu.
        byte[] er = new byte[pw * ph];
        for (int y = 1; y < ph - 1; y++) {
            for (int x = 1; x < pw - 1; x++) {
                int i = y * pw + x;
                if (m[i] == 1 && m[i - 1] == 1 && m[i + 1] == 1
                        && m[i - pw] == 1 && m[i - pw - 1] == 1 && m[i - pw + 1] == 1
                        && m[i + pw] == 1 && m[i + pw - 1] == 1 && m[i + pw + 1] == 1) er[i] = 1;
            }
        }
        byte[] op = new byte[pw * ph];
        for (int y = 1; y < ph - 1; y++) {
            for (int x = 1; x < pw - 1; x++) {
                int i = y * pw + x;
                if (er[i] == 1 || er[i - 1] == 1 || er[i + 1] == 1
                        || er[i - pw] == 1 || er[i - pw - 1] == 1 || er[i - pw + 1] == 1
                        || er[i + pw] == 1 || er[i + pw - 1] == 1 || er[i + pw + 1] == 1) op[i] = 1;
            }
        }

        // Distance transform chamfer 3-4.
        final int BIG = 1 << 20;
        int[] d = new int[pw * ph];
        for (int i = 0; i < d.length; i++) d[i] = op[i] == 1 ? BIG : 0;
        for (int y = 1; y < ph - 1; y++) {
            for (int x = 1; x < pw - 1; x++) {
                int i = y * pw + x;
                int v = d[i];
                if (v == 0) continue;
                v = Math.min(v, d[i - 1] + 3);
                v = Math.min(v, d[i - pw] + 3);
                v = Math.min(v, d[i - pw - 1] + 4);
                v = Math.min(v, d[i - pw + 1] + 4);
                d[i] = v;
            }
        }
        for (int y = ph - 2; y >= 1; y--) {
            for (int x = pw - 2; x >= 1; x--) {
                int i = y * pw + x;
                int v = d[i];
                if (v == 0) continue;
                v = Math.min(v, d[i + 1] + 3);
                v = Math.min(v, d[i + pw] + 3);
                v = Math.min(v, d[i + pw + 1] + 4);
                v = Math.min(v, d[i + pw - 1] + 4);
                d[i] = v;
            }
        }

        // Lượt 1: ước lượng bán kính bi (trung vị các đỉnh có kích thước hợp lý).
        double r0 = t.width() / 80.0;
        List<Peak> p1 = pickPeaks(d, pw, ph, L, T,
                (int) Math.round(3 * (0.75 * r0 - 0.5)), (int) Math.round(3 * (1.6 * r0 - 0.5)),
                1.2 * r0, 1.9 * r0);
        List<Double> radii = new ArrayList<>();
        for (Peak p : p1) if (p.valid) radii.add(p.d / 3.0 + 0.5);
        if (radii.isEmpty()) return;
        Collections.sort(radii);
        double rr = radii.get(radii.size() / 2);
        res.radius = rr;

        // Lượt 2: lấy bi với bán kính đã biết.
        List<Peak> p2 = pickPeaks(d, pw, ph, L, T,
                (int) Math.round(3 * (rr - 0.5) * 0.75), (int) Math.round(3 * (rr - 0.5) * 1.35),
                1.5 * rr, 1.9 * rr);
        for (Peak p : p2) {
            if (!p.valid) continue;
            // Tinh chỉnh tâm: trung bình các điểm gần đỉnh (không bị cây cơ kéo lệch).
            double sx = 0, sy = 0, c = 0;
            int win = (int) Math.ceil(0.7 * rr);
            double thr = 0.85 * p.d;
            for (int dy = -win; dy <= win; dy++) {
                for (int dx = -win; dx <= win; dx++) {
                    int gx = p.x - L + 1 + dx, gy = p.y - T + 1 + dy;
                    if (gx < 0 || gy < 0 || gx >= pw || gy >= ph) continue;
                    if (d[gy * pw + gx] >= thr) {
                        sx += gx;
                        sy += gy;
                        c++;
                    }
                }
            }
            Ball b = new Ball();
            if (c > 0) {
                b.x = sx / c - 1 + L + 0.5;
                b.y = sy / c - 1 + T + 0.5;
            } else {
                b.x = p.x + 0.5;
                b.y = p.y + 0.5;
            }
            colorStats(b, rr);
            res.balls.add(b);
        }
    }

    private List<Peak> pickPeaks(int[] d, int pw, int ph, int L, int T,
                                 int minD, int maxD, double sup, double zone) {
        long[] keys = new long[1024];
        int n = 0;
        for (int y = 1; y < ph - 1; y++) {
            for (int x = 1; x < pw - 1; x++) {
                int i = y * pw + x;
                int v = d[i];
                if (v < minD || v < 3) continue;
                if (v < d[i - 1] || v < d[i + 1] || v < d[i - pw] || v < d[i + pw]
                        || v < d[i - pw - 1] || v < d[i - pw + 1]
                        || v < d[i + pw - 1] || v < d[i + pw + 1]) continue;
                if (n == keys.length) keys = Arrays.copyOf(keys, n * 2);
                keys[n++] = ((long) v << 32) | i;
            }
        }
        Arrays.sort(keys, 0, n);
        List<Peak> acc = new ArrayList<>();
        double sup2 = sup * sup;
        for (int k = n - 1; k >= 0; k--) {
            int i = (int) (keys[k] & 0xffffffffL);
            int v = (int) (keys[k] >> 32);
            int x = i % pw - 1 + L, y = i / pw - 1 + T;
            if (inPocketZone(x + 0.5, y + 0.5, zone)) continue;
            boolean skip = false;
            for (Peak a : acc) {
                double dx = a.x - x, dy = a.y - y;
                if (dx * dx + dy * dy < sup2) {
                    skip = true;
                    break;
                }
            }
            if (skip) continue;
            Peak p = new Peak();
            p.x = x;
            p.y = y;
            p.d = v;
            p.valid = v >= minD && v <= maxD;
            acc.add(p);
        }
        return acc;
    }

    private boolean inPocketZone(double x, double y, double zone) {
        double cx = (table.l + table.r) / 2;
        double[][] pts = {{table.l, table.t}, {table.r, table.t}, {table.l, table.b},
                {table.r, table.b}, {cx, table.t}, {cx, table.b}};
        for (int k = 0; k < pts.length; k++) {
            double z = k >= 4 ? zone * 0.85 : zone;
            if (Math.hypot(x - pts[k][0], y - pts[k][1]) < z) return true;
        }
        return false;
    }

    // ------------------------------------------------- đường ngắm của game

    private boolean whiteAt(double x, double y) {
        int x0 = (int) Math.floor(x), y0 = (int) Math.floor(y);
        for (int dy = 0; dy <= 1; dy++) {
            for (int dx = 0; dx <= 1; dx++) {
                int xx = x0 + dx, yy = y0 + dy;
                if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
                int i = yy * w + xx;
                if (S[i] < 0.35f && V[i] > 0.78f) return true;
            }
        }
        return false;
    }

    /** Số điểm trắng liên tục (cho phép đứt ngắn) dọc tia từ tâm bi, bắt đầu ngay ngoài mép bi. */
    private int rayScore(double cx, double cy, double ang, double r, double maxLen) {
        double ux = Math.cos(ang), uy = Math.sin(ang);
        int count = 0, gap = 0;
        for (double t = 1.15 * r; t < maxLen; t += 1.0) {
            double x = cx + ux * t, y = cy + uy * t;
            if (x < 0 || y < 0 || x >= w - 1 || y >= h - 1) break;
            if (whiteAt(x, y)) {
                count++;
                gap = 0;
            } else if (++gap > 3) {
                break;
            }
        }
        return count;
    }

    /**
     * Tìm đường ngắm trắng mảnh mà game vẽ từ bi cái. Trả về {ux, uy, độ dài điểm trắng},
     * hoặc null nếu không có đường nào đủ dài (người chơi chưa ngắm).
     */
    public synchronized double[] findAim(double cx, double cy, double r) {
        if (V == null || w == 0) return null;
        double maxLen = table == null ? w : Math.hypot(table.width(), table.height());
        int best = 0;
        double bestAng = 0;
        for (int a = 0; a < 720; a++) {
            double ang = a * Math.PI / 360.0;
            int s = rayScore(cx, cy, ang, r, maxLen);
            if (s > best) {
                best = s;
                bestAng = ang;
            }
        }
        if (best < 4 * r) return null;
        // Tinh chỉnh ±0.6 độ, bước 0.05 độ. Gộp các góc ngang điểm rồi lấy trung bình cho ổn định.
        int top = 0;
        double[] sc = new double[25];
        for (int k = 0; k < 25; k++) {
            sc[k] = rayScore(cx, cy, bestAng + (k - 12) * 0.00087, r, maxLen);
            top = Math.max(top, (int) sc[k]);
        }
        double sa = 0, sw = 0;
        for (int k = 0; k < 25; k++) {
            if (sc[k] >= top - 1) {
                sa += (bestAng + (k - 12) * 0.00087);
                sw++;
            }
        }
        double ang = sa / sw;
        return new double[]{Math.cos(ang), Math.sin(ang), top};
    }

    private void colorStats(Ball b, double rr) {
        int cx = (int) b.x, cy = (int) b.y;
        int R = (int) Math.ceil(0.8 * rr);
        int wc = 0, tot = 0;
        double sv = 0;
        double lim = 0.64 * rr * rr;
        for (int dy = -R; dy <= R; dy++) {
            for (int dx = -R; dx <= R; dx++) {
                if (dx * dx + dy * dy > lim) continue;
                int x = cx + dx, y = cy + dy;
                if (x < 0 || y < 0 || x >= w || y >= h) continue;
                int i = y * w + x;
                tot++;
                sv += V[i];
                if (S[i] < 0.25f && V[i] > 0.72f) wc++;
            }
        }
        b.white = tot == 0 ? 0 : wc / (double) tot;
        b.meanV = tot == 0 ? 1 : sv / tot;
    }
}
