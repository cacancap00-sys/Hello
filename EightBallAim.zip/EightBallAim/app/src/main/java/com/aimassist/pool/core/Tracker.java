package com.aimassist.pool.core;

import java.util.ArrayList;
import java.util.List;

/**
 * Theo dõi bi giữa các khung hình: giữ id ổn định, lọc rung (đường ngắm không nhảy lung tung)
 * và chỉ công nhận bi sau khi thấy 2 khung liên tiếp.
 */
public final class Tracker {
    private final List<Ball> tr = new ArrayList<>();
    private int nextId = 1;

    public synchronized void reset() {
        tr.clear();
    }

    public synchronized List<Ball> update(List<Ball> det, double r) {
        int nt = tr.size(), nd = det.size();
        List<double[]> pairs = new ArrayList<>();
        for (int i = 0; i < nt; i++) {
            for (int j = 0; j < nd; j++) {
                double d = Math.hypot(tr.get(i).x - det.get(j).x, tr.get(i).y - det.get(j).y);
                if (d < 2.5 * r) pairs.add(new double[]{d, i, j});
            }
        }
        pairs.sort((a, b) -> Double.compare(a[0], b[0]));
        boolean[] ut = new boolean[nt], ud = new boolean[nd];
        for (double[] p : pairs) {
            int i = (int) p[1], j = (int) p[2];
            if (ut[i] || ud[j]) continue;
            ut[i] = true;
            ud[j] = true;
            Ball b = tr.get(i), d = det.get(j);
            double dist = p[0];
            if (dist > 0.9) { // dưới ~1px coi như đứng yên -> giữ nguyên vị trí
                double a = dist > 0.5 * r ? 0.85 : 0.6;
                b.x += (d.x - b.x) * a;
                b.y += (d.y - b.y) * a;
            }
            b.white += (d.white - b.white) * 0.4;
            b.meanV += (d.meanV - b.meanV) * 0.4;
            b.age++;
            b.miss = 0;
        }
        for (int i = 0; i < nt; i++) if (!ut[i]) tr.get(i).miss++;
        tr.removeIf(b -> b.miss >= 3);
        for (int j = 0; j < nd; j++) {
            if (ud[j]) continue;
            Ball n = det.get(j).copy();
            n.id = nextId++;
            n.age = 1;
            n.miss = 0;
            tr.add(n);
        }
        List<Ball> out = new ArrayList<>();
        for (Ball b : tr) if (b.age >= 2 && b.miss <= 2) out.add(b.copy());
        return out;
    }
}
