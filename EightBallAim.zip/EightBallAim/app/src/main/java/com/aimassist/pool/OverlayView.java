package com.aimassist.pool;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.MotionEvent;
import android.view.View;

import com.aimassist.pool.core.Scene;
import com.aimassist.pool.core.ShotPlanner;

/**
 * Lớp phủ toàn màn hình, trong suốt. Chỉ vẽ nét mảnh: đường ngắm, đường sau va chạm,
 * và một vòng tròn mảnh tại vị trí bi cái lúc chạm (bi ma). Không tô đặc nên không che bi.
 */
public class OverlayView extends View {

    public interface TapListener {
        void onTap(float x, float y);
    }

    private volatile Scene scene;
    private final Paint aim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint post = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ghost = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private TapListener tapListener;
    private boolean selectMode;

    public OverlayView(Context c) {
        super(c);
        float dp = c.getResources().getDisplayMetrics().density;

        aim.setStyle(Paint.Style.STROKE);
        aim.setStrokeWidth(1.1f * dp);
        aim.setColor(0xCCFFE070); // vàng nhạt, KHÔNG trắng: app đọc đường trắng của game nên không được nhầm với nét của chính nó

        post.setStyle(Paint.Style.STROKE);
        post.setStrokeWidth(0.9f * dp);
        post.setColor(0xB0A0FFB0);
        post.setPathEffect(new DashPathEffect(new float[]{5f * dp, 4f * dp}, 0));

        ghost.setStyle(Paint.Style.STROKE);
        ghost.setStrokeWidth(0.9f * dp);
        ghost.setColor(0xCCFFE070);
    }

    public void setScene(Scene s) {
        scene = s;
        postInvalidateOnAnimation();
    }

    public void setTapListener(TapListener l) {
        tapListener = l;
    }

    public void setSelectMode(boolean on) {
        selectMode = on;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        Scene s = scene;
        if (s == null || s.plan == null || getWidth() == 0 || s.w == 0) return;
        float sx = getWidth() / (float) s.w, sy = getHeight() / (float) s.h;
        // Chỉ vẽ khi khung chụp và cửa sổ cùng tỉ lệ (tránh lệch khi đang xoay màn hình).
        if (Math.abs(sx - sy) / sx > 0.03f) return;

        for (ShotPlanner.Poly p : s.plan.polys) {
            path.rewind();
            for (int i = 0; i < p.xy.length; i += 2) {
                float x = (float) p.xy[i] * sx, y = (float) p.xy[i + 1] * sy;
                if (i == 0) path.moveTo(x, y);
                else path.lineTo(x, y);
            }
            canvas.drawPath(path, p.kind == ShotPlanner.AIM ? aim : post);
        }
        if (!Double.isNaN(s.plan.gx)) {
            canvas.drawCircle((float) s.plan.gx * sx, (float) s.plan.gy * sy, (float) s.r * sx, ghost);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (!selectMode || tapListener == null) return false;
        if (e.getAction() == MotionEvent.ACTION_UP) {
            Scene s = scene;
            if (s != null && getWidth() > 0 && s.w > 0) {
                float k = s.w / (float) getWidth();
                tapListener.onTap(e.getX() * k, e.getY() * k);
            }
        }
        return true;
    }
}
