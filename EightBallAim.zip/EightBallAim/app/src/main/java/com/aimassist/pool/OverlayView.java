package com.aimassist.pool;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.MotionEvent;
import android.view.View;

import com.aimassist.pool.core.Scene;
import com.aimassist.pool.core.ShotPlanner;

/**
 * Lớp phủ toàn màn hình, trong suốt. Chỉ vẽ nét mảnh: đường ngắm, đường sau va chạm,
 * và một vòng tròn mảnh tại vị trí bi cái lúc chạm (bi ma). Không tô đặc nên không che bi.
 */
public class OverlayView extends View {

    public interface TapListener {
        void onTap(float x, float y);
    }

    private volatile Scene scene;
    private final Paint aim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint post = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint cuePost = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ghost = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private TapListener tapListener;
    private boolean selectMode;

    public OverlayView(Context c) {
        super(c);
        float dp = c.getResources().getDisplayMetrics().density;

        // Nét to, liền, sáng (không phải màu trắng để app không nhầm với đường trắng của game).
        aim.setStyle(Paint.Style.STROKE);
        aim.setStrokeWidth(3.2f * dp);
        aim.setStrokeCap(Paint.Cap.ROUND);
        aim.setStrokeJoin(Paint.Join.ROUND);
        aim.setColor(0xFFFFE15A);      // vàng: đường bi cái tới chỗ chạm (khi có ăn băng)

        post.setStyle(Paint.Style.STROKE);
        post.setStrokeWidth(3.0f * dp);
        post.setStrokeCap(Paint.Cap.ROUND);
        post.setStrokeJoin(Paint.Join.ROUND);
        post.setColor(0xFF6BFF8B);     // xanh lá: đường bi mục tiêu sau va chạm (có dội băng)

        cuePost.setStyle(Paint.Style.STROKE);
        cuePost.setStrokeWidth(3.0f * dp);
        cuePost.setStrokeCap(Paint.Cap.ROUND);
        cuePost.setStrokeJoin(Paint.Join.ROUND);
        cuePost.setColor(0xFF5AD8FF);  // xanh dương: hướng bi cái sau va chạm

        ghost.setStyle(Paint.Style.STROKE);
        ghost.setStrokeWidth(2.6f * dp);
        ghost.setColor(0xFFFFE15A);
    }

    public void setScene(Scene s) {
        scene = s;
        postInvalidateOnAnimation();
    }

    public void setTapListener(TapListener l) {
        tapListener = l;
    }

    public void setSelectMode(boolean on) {
        selectMode = on;
    }

    private final int[] loc = new int[2];
    private final android.util.DisplayMetrics dm = new android.util.DisplayMetrics();

    /**
     * Ảnh chụp luôn phủ TOÀN màn hình thật; cửa sổ lớp phủ có thể bé hơn (thanh trạng thái, tai thỏ,
     * thanh điều hướng) nên phải quy đổi qua toạ độ màn hình thật, không được so cỡ cửa sổ với cỡ ảnh.
     * Bản trước so tỉ lệ cửa sổ/ảnh và âm thầm KHÔNG vẽ gì khi lệch > 3%.
     */
    private boolean updateMapping(Scene s) {
        android.view.WindowManager wm = (android.view.WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE);
        wm.getDefaultDisplay().getRealMetrics(dm);
        if (dm.widthPixels < dm.heightPixels) return false; // đang dọc, game chạy ngang
        getLocationOnScreen(loc);
        mapX = dm.widthPixels / (float) s.w;
        mapY = dm.heightPixels / (float) s.h;
        return true;
    }

    private float mapX, mapY;

    private float vx(double x) {
        return (float) x * mapX - loc[0];
    }

    private float vy(double y) {
        return (float) y * mapY - loc[1];
    }

    @Override
    protected void onDraw(Canvas canvas) {
        Scene s = scene;
        if (s == null || s.plan == null || s.w == 0 || !updateMapping(s)) return;

        for (ShotPlanner.Poly p : s.plan.polys) {
            path.rewind();
            for (int i = 0; i < p.xy.length; i += 2) {
                float x = vx(p.xy[i]), y = vy(p.xy[i + 1]);
                if (i == 0) path.moveTo(x, y);
                else path.lineTo(x, y);
            }
            canvas.drawPath(path, p.kind == ShotPlanner.AIM ? aim : p.kind == ShotPlanner.CUE ? cuePost : post);
        }
        if (!Double.isNaN(s.plan.gx)) {
            canvas.drawCircle(vx(s.plan.gx), vy(s.plan.gy), (float) s.r * mapX, ghost);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (!selectMode || tapListener == null) return false;
        if (e.getAction() == MotionEvent.ACTION_UP) {
            Scene s = scene;
            if (s != null && s.w > 0 && updateMapping(s)) {
                tapListener.onTap(e.getRawX() / mapX, e.getRawY() / mapY);
            }
        }
        return true;
    }
}
