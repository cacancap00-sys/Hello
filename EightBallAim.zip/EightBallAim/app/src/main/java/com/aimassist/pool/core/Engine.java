package com.aimassist.pool.core;

import java.util.ArrayList;
import java.util.List;

/** Ghép nhận diện + theo dõi + tính đường. An toàn đa luồng (UI chọn bi, luồng chụp xử lý ảnh). */
public final class Engine {
    private final Detector det = new Detector();
    private final Tracker trk = new Tracker();

    private int selectedId = -1, autoId = -1;
    private boolean aimOk;
    private double aimAng;
    private int aimMiss, aimCueId = -1;
    private double[] aimRing;
    private final double[] walls = {Double.NaN, Double.NaN, Double.NaN, Double.NaN};
    private boolean centerMode;

    private Table tb;
    private double r;
    private List<Ball> balls = new ArrayList<>();
    private int w, h;

    public synchronized void setCenterMode(boolean c) {
        centerMode = c;
        autoId = -1;
    }

    public synchronized boolean isCenterMode() {
        return centerMode;
    }

    public synchronized Scene process(int[] px, int w, int h) {
        this.w = w;
        this.h = h;
        Detector.Result res = det.detect(px, w, h);
        if (res.table == null || res.radius <= 0) {
            tb = null;
            trk.update(new ArrayList<Ball>(), 8);
            balls = new ArrayList<>();
            Scene e = Scene.empty(w, h);
            e.status = "Chưa thấy bàn";
            return e;
        }
        r = (r <= 0 || Math.abs(res.radius - r) > 0.15 * r) ? res.radius : 0.9 * r + 0.1 * res.radius;
        tb = res.table;
        balls = trk.update(res.balls, r);
        updateAim();
        return rebuild();
    }

    /** Tìm bi cái thật sự (bi có đường ngắm / vòng bi ma của game) và hướng ngắm hiện tại. */
    private void updateAim() {
        Ball best = null;
        double[] bestLine = null, bestRing = null;
        double bestScore = 0;
        List<Ball> cands = new ArrayList<>();
        for (Ball b : balls) if (b.white >= 0.45) cands.add(b);
        // Lượt 1: bi nào có nét trắng dài đi ra thì là bi cái đang ngắm.
        for (Ball b : cands) {
            double[] ln = det.findAim(b.x, b.y, r);
            if (ln == null || ln[2] <= bestScore) continue;
            best = b;
            bestLine = ln;
            bestScore = ln[2];
            bestRing = det.findRingAlong(b.x, b.y, ln[0], ln[1], r, Math.max(0, ln[3] - 3 * r), ln[3] + 2 * r);
        }
        // Lượt 2: bi mục tiêu sát bi cái -> game chỉ vẽ đoạn rất ngắn + vòng bi ma cạnh bi cái.
        if (best == null) {
            cands.sort((x, y) -> Double.compare(y.white, x.white));
            for (Ball b : cands) {
                double[] rg = det.findRingNear(b.x, b.y, r);
                if (rg == null) continue;
                best = b;
                bestRing = rg;
                double ddx = rg[0] - b.x, ddy = rg[1] - b.y, dl = Math.hypot(ddx, ddy);
                bestLine = new double[]{ddx / dl, ddy / dl, 0, dl};
                break;
            }
        }
        if (best == null) {
            if (++aimMiss >= 3) {
                aimOk = false;
                aimCueId = -1;
                aimRing = null;
            }
            return;
        }
        aimMiss = 0;
        aimCueId = best.id;
        learnWalls(best, bestRing);
        double ang = Math.atan2(bestLine[1], bestLine[0]);
        boolean still = aimOk && Math.abs(Math.atan2(Math.sin(ang - aimAng), Math.cos(ang - aimAng))) < Math.toRadians(0.12);
        if (!still) aimAng = ang;
        // Vòng bi ma: giữ nguyên nếu dịch < 0.6px (chống rung).
        if (bestRing != null) {
            if (aimRing == null || Math.hypot(bestRing[0] - aimRing[0], bestRing[1] - aimRing[1]) >= 0.6) {
                aimRing = new double[]{bestRing[0], bestRing[1]};
            }
        } else {
            aimRing = null;
        }
        aimOk = true;
    }

    /**
     * Vòng bi ma chạm băng (không có bi nào cách ~2r) cho biết đúng vị trí băng mà tâm bi dội.
     * App học dần vị trí đó thay vì đoán, nên cú băng ngày càng chính xác.
     */
    private void learnWalls(Ball cue, double[] ring) {
        if (ring == null || tb == null) return;
        for (Ball b : balls) {
            if (b.id == cue.id) continue;
            double d = Math.hypot(b.x - ring[0], b.y - ring[1]);
            if (d < 2.6 * r) return; // vòng này là điểm chạm bi, không phải băng
        }
        double[] cur = ShotPlanner.defaultWalls(tb);
        for (int i = 0; i < 4; i++) if (!Double.isNaN(walls[i])) cur[i] = walls[i];
        double[] coord = {ring[0], ring[0], ring[1], ring[1]};
        int wi = -1;
        double bd = 1.6 * r;
        for (int i = 0; i < 4; i++) {
            double d = Math.abs(coord[i] - cur[i]);
            if (d < bd) {
                bd = d;
                wi = i;
            }
        }
        if (wi < 0) return;
        walls[wi] = Double.isNaN(walls[wi]) ? coord[wi] : 0.7 * walls[wi] + 0.3 * coord[wi];
    }

    /** Chạm vào một bi để chọn làm bi mục tiêu; chạm lại bi đó để quay về tự động. */
    public synchronized Scene select(double x, double y) {
        Ball best = null;
        double bd = 2.0 * r;
        for (Ball b : balls) {
            if (b.id == cueId()) continue;
            double d = Math.hypot(b.x - x, b.y - y);
            if (d < bd) {
                bd = d;
                best = b;
            }
        }
        if (best != null) selectedId = best.id == selectedId ? -1 : best.id;
        return rebuild();
    }

    private Ball cueBall() {
        if (aimCueId >= 0) {
            Ball c = find(aimCueId);
            if (c != null) return c;
        }
        Ball cue = null;
        for (Ball b : balls) {
            if (b.white >= 0.55 && (cue == null || b.white > cue.white)) cue = b;
        }
        return cue;
    }

    private int cueId() {
        Ball c = cueBall();
        return c == null ? -1 : c.id;
    }

    private Ball find(int id) {
        for (Ball b : balls) if (b.id == id) return b;
        return null;
    }

    private Scene rebuild() {
        if (tb == null) {
            Scene e = Scene.empty(w, h);
            e.status = "Chưa thấy bàn";
            return e;
        }
        Ball cue = cueBall();
        ShotPlanner.Plan plan = null;
        int tid = -1;
        boolean manual = false;
        if (cue != null) {
            ShotPlanner sp = new ShotPlanner(tb, r, balls, walls);
            Ball sel = find(selectedId);
            if (sel == null) selectedId = -1;
            if (aimOk && aimCueId == cue.id) {
                // Đường ngắm của game LUÔN được ưu tiên: người chơi xoay ngắm tới đâu, app đi theo tới đó.
                plan = aimRing != null
                        ? sp.planRing(cue, Math.cos(aimAng), Math.sin(aimAng), aimRing[0], aimRing[1])
                        : sp.planDirection(cue, Math.cos(aimAng), Math.sin(aimAng));
                tid = plan.targetId;
            } else if (sel != null && sel != cue) {
                plan = sp.plan(cue, sel, centerMode);
                tid = sel.id;
                manual = true;
            } else {
                ShotPlanner.Plan best = null;
                Ball bestBall = null;
                ShotPlanner.Plan prevPlan = null;
                Ball prev = find(autoId);
                for (Ball b : balls) {
                    if (b == cue) continue;
                    ShotPlanner.Plan p = sp.planAuto(cue, b, centerMode);
                    if (p == null) continue;
                    if (b == prev) prevPlan = p;
                    if (best == null || p.score < best.score) {
                        best = p;
                        bestBall = b;
                    }
                }
                // Trễ chọn: giữ bi cũ nếu không kém bi mới đáng kể -> đường không nhảy qua lại.
                if (prevPlan != null && best != null && prevPlan.score <= best.score + 8) {
                    best = prevPlan;
                    bestBall = prev;
                }
                plan = best;
                if (bestBall != null) {
                    autoId = bestBall.id;
                    tid = bestBall.id;
                } else {
                    autoId = -1;
                }
            }
        }
        Scene sc = new Scene(w, h, tb, r, new ArrayList<>(balls), plan, cue == null ? -1 : cue.id, tid, manual);
        sc.status = "Bàn ✓ " + balls.size() + " bi · bi cái " + (cue != null ? "✓" : "✗")
                + " · đường game " + (aimOk ? "✓" : "✗")
                + (plan != null && plan.bank ? " · ăn băng" : "");
        return sc;
    }
}
