package com.aimassist.pool.core;

import java.util.ArrayList;
import java.util.List;

/** Ghép nhận diện + theo dõi + tính đường. An toàn đa luồng (UI chọn bi, luồng chụp xử lý ảnh). */
public final class Engine {
    private final Detector det = new Detector();
    private final Tracker trk = new Tracker();

    private int selectedId = -1, autoId = -1;
    private boolean centerMode;

    private Table tb;
    private double r;
    private List<Ball> balls = new ArrayList<>();
    private int w, h;

    public synchronized void setCenterMode(boolean c) {
        centerMode = c;
        autoId = -1;
    }

    public synchronized boolean isCenterMode() {
        return centerMode;
    }

    public synchronized Scene process(int[] px, int w, int h) {
        this.w = w;
        this.h = h;
        Detector.Result res = det.detect(px, w, h);
        if (res.table == null || res.radius <= 0) {
            tb = null;
            trk.update(new ArrayList<Ball>(), 8);
            balls = new ArrayList<>();
            return Scene.empty(w, h);
        }
        r = (r <= 0 || Math.abs(res.radius - r) > 0.15 * r) ? res.radius : 0.9 * r + 0.1 * res.radius;
        tb = res.table;
        balls = trk.update(res.balls, r);
        return rebuild();
    }

    /** Chạm vào một bi để chọn làm bi mục tiêu; chạm lại bi đó để quay về tự động. */
    public synchronized Scene select(double x, double y) {
        Ball best = null;
        double bd = 2.0 * r;
        for (Ball b : balls) {
            if (b.id == cueId()) continue;
            double d = Math.hypot(b.x - x, b.y - y);
            if (d < bd) {
                bd = d;
                best = b;
            }
        }
        if (best != null) selectedId = best.id == selectedId ? -1 : best.id;
        return rebuild();
    }

    private Ball cueBall() {
        Ball cue = null;
        for (Ball b : balls) {
            if (b.white >= 0.55 && (cue == null || b.white > cue.white)) cue = b;
        }
        return cue;
    }

    private int cueId() {
        Ball c = cueBall();
        return c == null ? -1 : c.id;
    }

    private Ball find(int id) {
        for (Ball b : balls) if (b.id == id) return b;
        return null;
    }

    private Scene rebuild() {
        if (tb == null) return Scene.empty(w, h);
        Ball cue = cueBall();
        ShotPlanner.Plan plan = null;
        int tid = -1;
        boolean manual = false;
        if (cue != null) {
            ShotPlanner sp = new ShotPlanner(tb, r, balls);
            Ball sel = find(selectedId);
            if (sel == null) selectedId = -1;
            if (sel != null && sel != cue) {
                plan = sp.plan(cue, sel, centerMode);
                tid = sel.id;
                manual = true;
            } else {
                ShotPlanner.Plan best = null;
                Ball bestBall = null;
                ShotPlanner.Plan prevPlan = null;
                Ball prev = find(autoId);
                for (Ball b : balls) {
                    if (b == cue) continue;
                    ShotPlanner.Plan p = sp.planAuto(cue, b, centerMode);
                    if (p == null) continue;
                    if (b == prev) prevPlan = p;
                    if (best == null || p.score < best.score) {
                        best = p;
                        bestBall = b;
                    }
                }
                // Trễ chọn: giữ bi cũ nếu không kém bi mới đáng kể -> đường không nhảy qua lại.
                if (prevPlan != null && best != null && prevPlan.score <= best.score + 8) {
                    best = prevPlan;
                    bestBall = prev;
                }
                plan = best;
                if (bestBall != null) {
                    autoId = bestBall.id;
                    tid = bestBall.id;
                } else {
                    autoId = -1;
                }
            }
        }
        return new Scene(w, h, tb, r, new ArrayList<>(balls), plan, cue == null ? -1 : cue.id, tid, manual);
    }
}
