package com.aimassist.pool.core;

import java.util.Collections;
import java.util.List;

/** Kết quả một khung hình, toạ độ trong không gian ảnh đã thu nhỏ (w x h). */
public final class Scene {
    public final int w, h;
    public final Table table;
    public final double r;
    public final List<Ball> balls;
    public final ShotPlanner.Plan plan;
    public final int cueId, targetId;
    public final boolean manual;

    public Scene(int w, int h, Table table, double r, List<Ball> balls,
                 ShotPlanner.Plan plan, int cueId, int targetId, boolean manual) {
        this.w = w;
        this.h = h;
        this.table = table;
        this.r = r;
        this.balls = balls;
        this.plan = plan;
        this.cueId = cueId;
        this.targetId = targetId;
        this.manual = manual;
    }

    public static Scene empty(int w, int h) {
        return new Scene(w, h, null, 0, Collections.<Ball>emptyList(), null, -1, -1, false);
    }
}
