package com.aimassist.pool.core;

import java.util.ArrayList;
import java.util.List;

/**
 * Hình học cú đánh: bi ma (ghost ball), lỗ mục tiêu, đường phản xạ băng trước và sau va chạm,
 * hướng đi của bi cái / bi mục tiêu sau va chạm (va chạm đàn hồi, không xoáy).
 * Bi di chuyển bằng TÂM nên băng được co vào một bán kính bi (xl, xr, yt, yb).
 */
public final class ShotPlanner {
    public static final int AIM = 0, TARGET = 1, CUE = 2;
    private static final int MAX_BOUNCE = 3;

    public static final class Poly {
        public final int kind;
        public final double[] xy;

        Poly(int kind, double[] xy) {
            this.kind = kind;
            this.xy = xy;
        }
    }

    public static final class Plan {
        public final List<Poly> polys = new ArrayList<>();
        public double gx, gy;           // tâm bi ma (vị trí bi cái lúc chạm)
        public double score;            // thấp = dễ hơn
        public boolean bank;            // đường ngắm có ăn băng trước khi chạm bi
        public boolean pocketShot;      // ngắm theo lỗ (true) hay đánh vào tâm (false)
        public int targetId;
        public boolean followGame;      // kế hoạch bám theo đường ngắm trắng của game
        public double targetSpeed, cueSpeed; // thành phần vận tốc sau va chạm (0..1)
    }

    private static final class Trace {
        final List<double[]> pts;
        final int end; // 0 hết quãng, 1 chạm bi, 2 vào lỗ, 3 quá số lần dội
        final Ball hit; // bi bị chạm khi end == 1

        Trace(List<double[]> pts, int end, Ball hit) {
            this.pts = pts;
            this.end = end;
            this.hit = hit;
        }
    }

    private final Table tb;
    private final double r;
    private final List<Ball> balls;
    private final double xl, xr, yt, yb;
    private final double[][] pockets;

    /**
     * Băng mà TÂM bi dội. Đo từ video thật: vòng bi ma chạm băng trái nằm cách mép bàn nhận diện
     * ~3,1% chiều dài bàn (~2 bán kính bi). Thứ tự: trái, phải, trên, dưới.
     */
    public static double[] defaultWalls(Table tb) {
        double ins = 0.0314 * tb.width();
        return new double[]{tb.l + ins, tb.r - ins, tb.t + ins, tb.b - ins};
    }

    public ShotPlanner(Table tb, double r, List<Ball> balls) {
        this(tb, r, balls, null);
    }

    /** learned: băng đã học từ vòng bi ma của game (NaN = dùng mặc định). */
    public ShotPlanner(Table tb, double r, List<Ball> balls, double[] learned) {
        this.tb = tb;
        this.r = r;
        this.balls = balls;
        double[] w = defaultWalls(tb);
        if (learned != null) {
            for (int i = 0; i < 4; i++) if (!Double.isNaN(learned[i])) w[i] = learned[i];
        }
        xl = w[0];
        xr = w[1];
        yt = w[2];
        yb = w[3];
        double cx = (tb.l + tb.r) / 2, k = 0.5 * r;
        pockets = new double[][]{
                {tb.l + k, tb.t + k}, {tb.r - k, tb.t + k},
                {tb.l + k, tb.b - k}, {tb.r - k, tb.b - k},
                {cx, tb.t + 0.2 * r}, {cx, tb.b - 0.2 * r}};
    }

    // ------------------------------------------------------------ API

    /** Chọn thủ công: luôn trả về kế hoạch (rơi về đánh tâm nếu không có lỗ phù hợp). */
    public Plan plan(Ball cue, Ball tg, boolean centerMode) {
        Plan p = centerMode ? null : bestPocket(cue, tg);
        if (p == null) p = tryCenter(cue, tg, true);
        return p;
    }

    /** Tự chọn: trả về null nếu bi này không có cú nào khả thi. */
    public Plan planAuto(Ball cue, Ball tg, boolean centerMode) {
        Plan p = centerMode ? tryCenter(cue, tg, false) : bestPocket(cue, tg);
        if (p != null && tg.meanV < 0.22) p.score += 150; // bi 8: ưu tiên thấp
        return p;
    }

    // ------------------------------------------------------- ứng viên

    private Plan bestPocket(Ball cue, Ball tg) {
        Plan best = null;
        for (double[] p : pockets) {
            Plan c = tryPocket(cue, tg, p);
            if (c != null && (best == null || c.score < best.score)) best = c;
        }
        return best;
    }

    private Plan tryPocket(Ball cue, Ball tg, double[] p) {
        double dx = p[0] - tg.x, dy = p[1] - tg.y;
        double tl = Math.hypot(dx, dy);
        if (tl < 2 * r) return null;
        dx /= tl;
        dy /= tl;
        double gx = tg.x - dx * 2 * r, gy = tg.y - dy * 2 * r;
        if (gx < xl - 0.25 * r || gx > xr + 0.25 * r || gy < yt - 0.25 * r || gy > yb + 0.25 * r)
            return null;
        if (!clear(tg.x, tg.y, p[0], p[1], tg, cue, 1.95 * r)) return null;
        List<double[]> route = route(cue, tg, gx, gy, dx, dy);
        if (route == null) return null;
        double[] prev = route.get(route.size() - 2);
        double vx = gx - prev[0], vy = gy - prev[1], vl = Math.hypot(vx, vy);
        double cos = (vx * dx + vy * dy) / vl;
        boolean bank = route.size() == 3;
        double len = 0;
        for (int i = 1; i < route.size(); i++)
            len += Math.hypot(route.get(i)[0] - route.get(i - 1)[0], route.get(i)[1] - route.get(i - 1)[1]);
        double score = (1 - cos) * 120 + (bank ? 60 : 0) + 0.03 * (len + tl);
        Plan pl = finish(cue, tg, route, score, bank);
        pl.pocketShot = true;
        return pl;
    }

    private Plan tryCenter(Ball cue, Ball tg, boolean force) {
        double dx = tg.x - cue.x, dy = tg.y - cue.y;
        double l = Math.hypot(dx, dy);
        if (l < 2 * r + 1e-6) return null;
        dx /= l;
        dy /= l;
        double gx = tg.x - dx * 2 * r, gy = tg.y - dy * 2 * r;
        List<double[]> route = route(cue, tg, gx, gy, dx, dy);
        boolean bank = route != null && route.size() == 3;
        if (route == null) {
            if (!force) return null;
            route = new ArrayList<>();
            route.add(new double[]{cue.x, cue.y});
            route.add(new double[]{gx, gy});
        }
        return finish(cue, tg, route, l * 0.05 + (bank ? 60 : 0), bank);
    }

    /** Đường đi của tâm bi cái tới bi ma: thẳng, hoặc ăn 1 băng nếu bị chắn. */
    private List<double[]> route(Ball cue, Ball tg, double gx, double gy, double nx, double ny) {
        List<double[]> out = new ArrayList<>();
        out.add(new double[]{cue.x, cue.y});
        double vx = gx - cue.x, vy = gy - cue.y, vl = Math.hypot(vx, vy);
        if (vl > 1e-6 && (vx * nx + vy * ny) / vl >= 0.25
                && clear(cue.x, cue.y, gx, gy, cue, tg, 1.95 * r)) {
            out.add(new double[]{gx, gy});
            return out;
        }
        double[] w = bank(cue, tg, gx, gy, nx, ny);
        if (w == null) return null;
        out.add(w);
        out.add(new double[]{gx, gy});
        return out;
    }

    private double[] bank(Ball cue, Ball tg, double gx, double gy, double nx, double ny) {
        double best = Double.MAX_VALUE;
        double[] res = null;
        for (int w = 0; w < 4; w++) {
            double mx = gx, my = gy;
            if (w == 0) mx = 2 * xl - gx;
            else if (w == 1) mx = 2 * xr - gx;
            else if (w == 2) my = 2 * yt - gy;
            else my = 2 * yb - gy;
            double ddx = mx - cue.x, ddy = my - cue.y, wx, wy, t;
            if (w < 2) {
                double wxv = w == 0 ? xl : xr;
                if (Math.abs(ddx) < 1e-9) continue;
                t = (wxv - cue.x) / ddx;
                wx = wxv;
                wy = cue.y + t * ddy;
            } else {
                double wyv = w == 2 ? yt : yb;
                if (Math.abs(ddy) < 1e-9) continue;
                t = (wyv - cue.y) / ddy;
                wy = wyv;
                wx = cue.x + t * ddx;
            }
            if (t <= 0.001 || t >= 1) continue;
            if (wx < xl - 1e-6 || wx > xr + 1e-6 || wy < yt - 1e-6 || wy > yb + 1e-6) continue;
            double lx = gx - wx, ly = gy - wy, ll = Math.hypot(lx, ly);
            if (ll < 1e-6 || (lx * nx + ly * ny) / ll < 0.25) continue;
            if (!clear(cue.x, cue.y, wx, wy, cue, tg, 1.95 * r)) continue;
            if (!clear(wx, wy, gx, gy, cue, tg, 1.95 * r)) continue;
            double len = Math.hypot(wx - cue.x, wy - cue.y) + ll;
            if (len < best) {
                best = len;
                res = new double[]{wx, wy};
            }
        }
        return res;
    }

    // ------------------------------------------- dựng đường + sau va chạm

    private Plan finish(Ball cue, Ball tg, List<double[]> route, double score, boolean bank) {
        Plan pl = new Plan();
        pl.targetId = tg.id;
        pl.bank = bank;
        pl.score = score;
        double[] g = route.get(route.size() - 1);
        pl.gx = g[0];
        pl.gy = g[1];

        List<double[]> aim = new ArrayList<>();
        for (double[] p : route) aim.add(p.clone());
        trimStart(aim, r);
        trimEnd(aim, r);
        if (aim.size() >= 2) pl.polys.add(new Poly(AIM, flat(aim)));

        double[] prev = route.get(route.size() - 2);
        double ux = g[0] - prev[0], uy = g[1] - prev[1], ul = Math.hypot(ux, uy);
        if (ul < 1e-9) return pl;
        ux /= ul;
        uy /= ul;
        double nx = tg.x - g[0], ny = tg.y - g[1], nl = Math.hypot(nx, ny);
        if (nl < 1e-9) return pl;
        nx /= nl;
        ny /= nl;
        double sT = Math.max(0, ux * nx + uy * ny);
        double tx = ux - sT * nx, ty = uy - sT * ny, sC = Math.hypot(tx, ty);
        pl.targetSpeed = sT;
        pl.cueSpeed = sC;

        Trace tt = trace(tg.x, tg.y, nx, ny, 0.9 * tb.width(), cue, tg);
        trimStart(tt.pts, r);
        if (tt.end == 1) trimEnd(tt.pts, r);
        if (tt.pts.size() >= 2) pl.polys.add(new Poly(TARGET, flat(tt.pts)));

        if (sC > 0.08) {
            tx /= sC;
            ty /= sC;
            Trace ct = trace(g[0], g[1], tx, ty, 0.6 * tb.width() * sC, cue, tg);
            trimStart(ct.pts, r);
            if (ct.end == 1) trimEnd(ct.pts, r);
            if (ct.pts.size() >= 2) pl.polys.add(new Poly(CUE, flat(ct.pts)));
        }
        return pl;
    }

    /** Theo dõi tâm bi di chuyển: dội băng, dừng khi chạm bi khác hoặc vào lỗ. */
    private Trace trace(double sx, double sy, double dx, double dy, double budget, Ball ex1, Ball ex2) {
        List<double[]> pts = new ArrayList<>();
        pts.add(new double[]{sx, sy});
        double len = Math.hypot(dx, dy);
        dx /= len;
        dy /= len;
        double x = sx, y = sy;
        int bounces = 0, end = 0;
        Ball hitBall = null;
        while (budget > 1e-6) {
            double tmax = budget;
            int ev = 0, wall = -1;
            Ball evBall = null;
            if (dx > 1e-9) {
                double t = (xr - x) / dx;
                if (t > 1e-7 && t < tmax) { tmax = t; ev = 1; wall = 0; }
            } else if (dx < -1e-9) {
                double t = (xl - x) / dx;
                if (t > 1e-7 && t < tmax) { tmax = t; ev = 1; wall = 0; }
            }
            if (dy > 1e-9) {
                double t = (yb - y) / dy;
                if (t > 1e-7 && t < tmax) { tmax = t; ev = 1; wall = 1; }
            } else if (dy < -1e-9) {
                double t = (yt - y) / dy;
                if (t > 1e-7 && t < tmax) { tmax = t; ev = 1; wall = 1; }
            }
            for (Ball b : balls) {
                if (b == ex1 || b == ex2 || b.id == ex1.id || b.id == ex2.id) continue;
                double t = rayCircle(x, y, dx, dy, b.x, b.y, 2 * r);
                if (t > 1e-7 && t < tmax) { tmax = t; ev = 2; evBall = b; }
            }
            for (double[] p : pockets) {
                double t = rayCircle(x, y, dx, dy, p[0], p[1], 1.4 * r);
                if (t == -1) t = 0;
                if (t >= 0 && t < tmax) { tmax = t; ev = 3; }
            }
            x += dx * tmax;
            y += dy * tmax;
            pts.add(new double[]{x, y});
            budget -= tmax;
            if (ev == 0) { end = 0; break; }
            if (ev == 2) { end = 1; hitBall = evBall; break; }
            if (ev == 3) { end = 2; break; }
            // Chạm băng ngay miệng lỗ -> bi rơi vào lỗ, không dội.
            boolean mouth = false;
            for (double[] p : pockets) {
                if (Math.hypot(x - p[0], y - p[1]) < 1.7 * r) { mouth = true; break; }
            }
            if (mouth) { end = 2; break; }
            if (wall == 0) dx = -dx; else dy = -dy;
            if (++bounces > MAX_BOUNCE) { end = 3; break; }
        }
        return new Trace(pts, end, hitBall);
    }

    /**
     * Bám theo đường ngắm của game: bắn tia từ tâm bi cái theo hướng (ux, uy), dội băng tối đa 3 lần,
     * dừng ở bi đầu tiên bị chạm rồi tính hướng đi của bi mục tiêu và bi cái sau va chạm.
     */
    public Plan planDirection(Ball cue, double ux, double uy) {
        Trace tr = trace(cue.x, cue.y, ux, uy, 2.5 * tb.width(), cue, cue);
        Plan pl;
        if (tr.end == 1 && tr.hit != null) {
            List<double[]> route = new ArrayList<>(tr.pts);
            pl = finish(cue, tr.hit, route, 0, route.size() > 2);
        } else {
            pl = new Plan();
            pl.targetId = -1;
            pl.bank = tr.pts.size() > 2;
            pl.gx = Double.NaN;
            pl.gy = Double.NaN;
            List<double[]> aim = new ArrayList<>(tr.pts);
            trimStart(aim, r);
            if (aim.size() >= 2) pl.polys.add(new Poly(AIM, flat(aim)));
        }
        pl.followGame = true;
        dropFirstLeg(pl);
        return pl;
    }

    /**
     * Đoạn đầu (bi cái -> điểm đầu tiên) trùng đường trắng của game nên không vẽ lại: vừa gọn
     * màn hình vừa không che đường game (app còn cần đọc đường đó).
     */
    private static void dropFirstLeg(Plan pl) {
        for (int i = 0; i < pl.polys.size(); i++) {
            Poly p = pl.polys.get(i);
            if (p.kind == AIM) {
                if (p.xy.length <= 4) pl.polys.remove(i);
                else pl.polys.set(i, new Poly(AIM, java.util.Arrays.copyOfRange(p.xy, 2, p.xy.length)));
                return;
            }
        }
    }

    /**
     * Bám theo VÒNG TRÒN bi ma của game (g = tâm bi cái lúc chạm, ux/uy = hướng ngắm).
     * Vòng cách một bi ~2r -> chạm bi: lấy đúng điểm chạm của game. Vòng sát băng -> chạm băng:
     * dội rồi dò tiếp tới bi đầu tiên.
     */
    public Plan planRing(Ball cue, double ux, double uy, double gx, double gy) {
        double dx = gx - cue.x, dy = gy - cue.y, dl = Math.hypot(dx, dy);
        if (dl > 0.6 * r) {
            ux = dx / dl;
            uy = dy / dl;
        }
        Ball hit = null;
        double bd = Double.MAX_VALUE;
        for (Ball b : balls) {
            if (b.id == cue.id) continue;
            double d = Math.abs(Math.hypot(b.x - gx, b.y - gy) - 2 * r);
            if (d < bd) {
                bd = d;
                hit = b;
            }
        }
        List<double[]> route = new ArrayList<>();
        if (hit != null && bd <= 0.5 * r) {
            if (dl > 0.6 * r) route.add(new double[]{cue.x, cue.y});
            else route.add(new double[]{gx - ux * 2, gy - uy * 2});
            route.add(new double[]{gx, gy});
            Plan pl = finish(cue, hit, route, 0, false);
            pl.followGame = true;
            dropFirstLeg(pl);
            return pl;
        }
        // Chạm băng gần nhất?
        double[] dist = {Math.abs(gx - xl), Math.abs(gx - xr), Math.abs(gy - yt), Math.abs(gy - yb)};
        int wi = 0;
        for (int i = 1; i < 4; i++) if (dist[i] < dist[wi]) wi = i;
        if (dist[wi] > 1.6 * r) return planDirection(cue, ux, uy);
        double rx = wi < 2 ? -ux : ux, ry = wi < 2 ? uy : -uy;
        Trace tr = trace(gx, gy, rx, ry, 2.5 * tb.width(), cue, cue);
        route.add(new double[]{cue.x, cue.y});
        route.addAll(tr.pts);
        Plan pl;
        if (tr.end == 1 && tr.hit != null) {
            pl = finish(cue, tr.hit, route, 0, true);
        } else {
            pl = new Plan();
            pl.targetId = -1;
            pl.bank = true;
            pl.gx = Double.NaN;
            pl.gy = Double.NaN;
            List<double[]> aim = new ArrayList<>(route);
            trimStart(aim, r);
            if (aim.size() >= 2) pl.polys.add(new Poly(AIM, flat(aim)));
        }
        pl.followGame = true;
        dropFirstLeg(pl);
        return pl;
    }

    /** Giao điểm vào đường tròn: t >= 0; -1 nếu điểm đầu đã nằm trong; NaN nếu không giao. */
    private static double rayCircle(double x, double y, double dx, double dy,
                                    double cx, double cy, double R) {
        double fx = x - cx, fy = y - cy;
        double b = fx * dx + fy * dy;
        double c = fx * fx + fy * fy - R * R;
        if (c < 0) return -1;
        double disc = b * b - c;
        if (disc < 0) return Double.NaN;
        double t1 = -b - Math.sqrt(disc);
        return t1 >= 0 ? t1 : Double.NaN;
    }

    // ------------------------------------------------------- tiện ích

    private boolean clear(double ax, double ay, double bx, double by, Ball e1, Ball e2, double minDist) {
        for (Ball b : balls) {
            if (b.id == e1.id || b.id == e2.id) continue;
            if (segDist(b.x, b.y, ax, ay, bx, by) < minDist) return false;
        }
        return true;
    }

    private static double segDist(double px, double py, double ax, double ay, double bx, double by) {
        double dx = bx - ax, dy = by - ay, l2 = dx * dx + dy * dy;
        double t = l2 < 1e-9 ? 0 : ((px - ax) * dx + (py - ay) * dy) / l2;
        t = Math.max(0, Math.min(1, t));
        return Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
    }

    private static void trimStart(List<double[]> pts, double d) {
        if (pts.size() < 2) return;
        double[] a = pts.get(0), b = pts.get(1);
        double l = Math.hypot(b[0] - a[0], b[1] - a[1]);
        if (l > d + 1.0) {
            a[0] += (b[0] - a[0]) / l * d;
            a[1] += (b[1] - a[1]) / l * d;
        } else {
            pts.remove(0);
        }
    }

    private static void trimEnd(List<double[]> pts, double d) {
        if (pts.size() < 2) return;
        double[] a = pts.get(pts.size() - 1), b = pts.get(pts.size() - 2);
        double l = Math.hypot(b[0] - a[0], b[1] - a[1]);
        if (l > d + 1.0) {
            a[0] += (b[0] - a[0]) / l * d;
            a[1] += (b[1] - a[1]) / l * d;
        } else {
            pts.remove(pts.size() - 1);
        }
    }

    private static double[] flat(List<double[]> pts) {
        double[] o = new double[pts.size() * 2];
        for (int i = 0; i < pts.size(); i++) {
            o[2 * i] = pts.get(i)[0];
            o[2 * i + 1] = pts.get(i)[1];
        }
        return o;
    }
}
