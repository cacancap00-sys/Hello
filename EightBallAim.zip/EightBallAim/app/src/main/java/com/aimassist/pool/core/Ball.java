package com.aimassist.pool.core;

public final class Ball {
    public int id;
    public double x, y;
    /** Tỉ lệ điểm ảnh "trắng" trong thân bi (bi cái ~ cao nhất). */
    public double white;
    /** Độ sáng trung bình (bi số 8 rất tối). */
    public double meanV = 1;
    public int age, miss;

    public Ball copy() {
        Ball c = new Ball();
        c.id = id;
        c.x = x;
        c.y = y;
        c.white = white;
        c.meanV = meanV;
        c.age = age;
        c.miss = miss;
        return c;
    }
}
