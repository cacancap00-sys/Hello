package com.aimassist.pool.core;

/** Vùng nỉ của bàn (toạ độ cạnh pixel, không gian ảnh đã thu nhỏ). */
public final class Table {
    public final double l, t, r, b;

    public Table(double l, double t, double r, double b) {
        this.l = l;
        this.t = t;
        this.r = r;
        this.b = b;
    }

    public double width() {
        return r - l;
    }

    public double height() {
        return b - t;
    }
}
