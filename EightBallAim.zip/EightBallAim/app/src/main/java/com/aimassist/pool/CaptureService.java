package com.aimassist.pool;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.aimassist.pool.core.Engine;
import com.aimassist.pool.core.Scene;

import java.nio.ByteBuffer;

/**
 * Chụp màn hình (MediaProjection) -> nhận diện bàn/bi -> vẽ đường ngắm lên lớp phủ.
 * Chạy nền cùng game 8 Ball Pool; lớp phủ không nhận chạm nên không cản thao tác trong game.
 */
public class CaptureService extends Service {
    static final String EXTRA_CODE = "code";
    static final String EXTRA_DATA = "data";
    static final String ACTION_STOP = "com.aimassist.pool.STOP";
    private static final String CHANNEL = "aim";
    private static final String TAG = "PoolAim";

    private static final int PROC_W = 800;        // chiều rộng ảnh dùng để phân tích
    private static final long MIN_INTERVAL = 66;  // ~15 khung/giây tối đa

    private final Engine engine = new Engine();
    private MediaProjection projection;
    private VirtualDisplay vd;
    private ImageReader reader;
    private HandlerThread thread;
    private Handler bg;
    private WindowManager wm;
    private OverlayView overlay;
    private WindowManager.LayoutParams overlayLp;
    private LinearLayout panel;
    private TextView statusView;
    private String lastStatus = "";
    private boolean selectMode;
    private long lastTs;
    private int[] buf;

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent == null || projection != null) return START_NOT_STICKY;
        int code = intent.getIntExtra(EXTRA_CODE, 0);
        Intent data = intent.getParcelableExtra(EXTRA_DATA);
        if (data == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        startForegroundCompat();
        try {
            startCapture(code, data);
            addOverlay();
            addPanel();
        } catch (Throwable t) {
            Log.e(TAG, "start failed", t);
            Toast.makeText(this, "Không bật được: " + t.getMessage(), Toast.LENGTH_LONG).show();
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    // ------------------------------------------------------------ thông báo

    private void startForegroundCompat() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "8 Pool Aim",
                NotificationManager.IMPORTANCE_LOW));
        Intent stop = new Intent(this, CaptureService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 1, stop,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentTitle("8 Pool Aim đang chạy")
                .setContentText("Mở game rồi xoay ngang màn hình")
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, android.R.drawable.ic_delete), "Tắt", pi).build())
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(1, n);
        }
    }

    // --------------------------------------------------------------- chụp

    private void startCapture(int code, Intent data) {
        thread = new HandlerThread("pool-aim");
        thread.start();
        bg = new Handler(thread.getLooper());

        MediaProjectionManager mpm = getSystemService(MediaProjectionManager.class);
        projection = mpm.getMediaProjection(code, data);
        projection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                new Handler(Looper.getMainLooper()).post(CaptureService.this::stopSelf);
            }
        }, bg);

        DisplayMetrics dm = new DisplayMetrics();
        Display d = getSystemService(DisplayManager.class).getDisplay(Display.DEFAULT_DISPLAY);
        d.getRealMetrics(dm);
        // Game 8 Ball Pool chạy ngang: luôn chụp theo khung ngang.
        int W = Math.max(dm.widthPixels, dm.heightPixels);
        int H = Math.min(dm.widthPixels, dm.heightPixels);
        int capW = W;
        while (capW > 1400) capW /= 2;
        int capH = Math.round(H * (capW / (float) W));

        reader = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2);
        reader.setOnImageAvailableListener(this::onFrame, bg);
        vd = projection.createVirtualDisplay("pool-aim", capW, capH, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, bg);
    }

    private void onFrame(ImageReader r) {
        Image img = null;
        try {
            img = r.acquireLatestImage();
            if (img == null) return;
            long now = SystemClock.uptimeMillis();
            if (now - lastTs < MIN_INTERVAL) return;
            lastTs = now;

            int W = img.getWidth(), H = img.getHeight();
            int pw = Math.min(PROC_W, W);
            int ph = Math.max(1, Math.round(H * (pw / (float) W)));
            if (buf == null || buf.length != pw * ph) {
                buf = new int[pw * ph];
            }
            Image.Plane pl = img.getPlanes()[0];
            ByteBuffer bb = pl.getBuffer();
            int rs = pl.getRowStride(), ps = pl.getPixelStride();
            // Thu nhỏ bằng trung bình 2x2 điểm mẫu: nét trắng mảnh của game không bị đứt/mất.
            for (int y = 0; y < ph; y++) {
                int y0 = Math.min(H - 1, (int) (y * (float) H / ph + 0.25f * H / ph));
                int y1 = Math.min(H - 1, (int) (y * (float) H / ph + 0.75f * H / ph));
                int o = y * pw;
                for (int x = 0; x < pw; x++) {
                    int x0 = Math.min(W - 1, (int) (x * (float) W / pw + 0.25f * W / pw));
                    int x1 = Math.min(W - 1, (int) (x * (float) W / pw + 0.75f * W / pw));
                    int sr = 0, sg = 0, sb = 0;
                    for (int k = 0; k < 4; k++) {
                        int i = (k < 2 ? y0 : y1) * rs + ((k & 1) == 0 ? x0 : x1) * ps;
                        sr += bb.get(i) & 0xff;
                        sg += bb.get(i + 1) & 0xff;
                        sb += bb.get(i + 2) & 0xff;
                    }
                    buf[o + x] = ((sr >> 2) << 16) | ((sg >> 2) << 8) | (sb >> 2);
                }
            }
            final Scene s = engine.process(buf, pw, ph);
            final OverlayView ov = overlay;
            if (ov != null) {
                ov.post(() -> {
                    ov.setScene(s);
                    TextView sv = statusView;
                    if (sv != null && !s.status.equals(lastStatus)) {
                        lastStatus = s.status;
                        sv.setText(s.status);
                    }
                });
            }
        } catch (Throwable t) {
            Log.e(TAG, "frame", t);
        } finally {
            if (img != null) img.close();
        }
    }

    // -------------------------------------------------------------- lớp phủ

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void addOverlay() {
        wm = getSystemService(WindowManager.class);
        overlay = new OverlayView(this);
        overlay.setTapListener((x, y) -> {
            Scene s = engine.select(x, y);
            overlay.setScene(s);
            setSelectMode(false);
        });
        overlayLp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        overlayLp.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 28) {
            overlayLp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        wm.addView(overlay, overlayLp);
    }

    private TextView button(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(13);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(10), dp(6), dp(10), dp(6));
        return t;
    }

    private void addPanel() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.HORIZONTAL);
        GradientDrawable bgd = new GradientDrawable();
        bgd.setColor(0x80000000);
        bgd.setCornerRadius(dp(14));
        panel.setBackground(bgd);

        TextView handle = button("⠿");
        TextView close = button("✕");
        statusView = button("Đang tìm bàn…");
        statusView.setTextSize(11);
        statusView.setTextColor(0xFFCFE8FF);
        panel.addView(handle);
        panel.addView(statusView);
        panel.addView(close);

        final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = dp(8);
        lp.y = dp(8);

        handle.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy;
            int sx, sy;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        dx = e.getRawX();
                        dy = e.getRawY();
                        sx = lp.x;
                        sy = lp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.x = sx + Math.round(e.getRawX() - dx);
                        lp.y = sy + Math.round(e.getRawY() - dy);
                        wm.updateViewLayout(panel, lp);
                        return true;
                    default:
                        return true;
                }
            }
        });
        close.setOnClickListener(v -> stopSelf());
        wm.addView(panel, lp);
    }

    private void setSelectMode(boolean on) {
        selectMode = on;
        overlay.setSelectMode(on);
        if (on) overlayLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        else overlayLp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        wm.updateViewLayout(overlay, overlayLp);
        if (on) Toast.makeText(this, "Chạm vào bi muốn đánh (chạm lại để về tự động)", Toast.LENGTH_SHORT).show();
    }

    // ------------------------------------------------------------- dọn dẹp

    @Override
    public void onDestroy() {
        try {
            if (overlay != null) wm.removeView(overlay);
        } catch (Throwable ignored) {
        }
        try {
            if (panel != null) wm.removeView(panel);
        } catch (Throwable ignored) {
        }
        overlay = null;
        panel = null;
        if (vd != null) vd.release();
        if (reader != null) reader.close();
        if (projection != null) {
            try {
                projection.stop();
            } catch (Throwable ignored) {
            }
        }
        if (thread != null) thread.quitSafely();
        super.onDestroy();
    }
}
