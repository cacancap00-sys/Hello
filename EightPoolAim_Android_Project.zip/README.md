# 8 Pool Aim — bản thử nghiệm độc lập

## Chức năng hiện có
- Bàn bi-a mô phỏng trong ứng dụng Android.
- Kéo bi cái và bi mục tiêu để thay đổi vị trí.
- Bật/tắt riêng: đường ngắm, hướng bi cái, góc va chạm, đường phụ.
- Nút đặt lại vị trí.

## Mở và build APK
1. Giải nén thư mục `EightPoolAim`.
2. Mở thư mục bằng Android Studio (Open).
3. Chờ Gradle Sync và cài Android SDK Platform 35 nếu Android Studio yêu cầu.
4. Chọn Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug nằm tại `app/build/outputs/apk/debug/app-debug.apk`.

Đây là app mô phỏng độc lập, không overlay, không đọc màn hình và không can thiệp vào game 8 Ball Pool.
