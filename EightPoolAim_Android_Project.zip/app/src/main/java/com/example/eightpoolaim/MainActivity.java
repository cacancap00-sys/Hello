package com.example.eightpoolaim;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import android.content.Context;

public class MainActivity extends Activity {
    AimTable table;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(12,18,28));
        getWindow().setNavigationBarColor(Color.rgb(12,18,28));
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16),dp(12),dp(16),dp(12));
        page.setBackgroundColor(Color.rgb(12,18,28));

        TextView title = new TextView(this);
        title.setText("8 POOL AIM");
        title.setTextColor(Color.WHITE);
        title.setTextSize(21);
        title.setTypeface(null,1);
        page.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Bàn mô phỏng • Kéo bi để căn góc");
        sub.setTextColor(Color.rgb(165,180,198));
        sub.setTextSize(12);
        page.addView(sub);

        table = new AimTable(this);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1,0,1);
        tp.topMargin=dp(14); tp.bottomMargin=dp(12);
        page.addView(table,tp);

        TextView panelTitle = new TextView(this);
        panelTitle.setText("BẢNG ĐIỀU KHIỂN ĐƯỜNG KẺ");
        panelTitle.setTextColor(Color.WHITE);
        panelTitle.setTextSize(13);
        panelTitle.setTypeface(null,1);
        page.addView(panelTitle);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        addToggle(row1,"Đường ngắm",true,0);
        addToggle(row1,"Hướng bi cái",true,1);
        page.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        addToggle(row2,"Góc va chạm",true,2);
        addToggle(row2,"Đường phụ",false,3);
        page.addView(row2);

        Button reset = new Button(this);
        reset.setText("ĐẶT LẠI VỊ TRÍ BI");
        reset.setOnClickListener(v -> table.reset());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1,dp(48));
        bp.topMargin=dp(8);
        page.addView(reset,bp);

        TextView note = new TextView(this);
        note.setText("Bản thử nghiệm độc lập — không đọc hoặc can thiệp vào 8 Ball Pool.");
        note.setTextColor(Color.rgb(130,148,168));
        note.setTextSize(10);
        note.setPadding(0,dp(8),0,0);
        page.addView(note);
        setContentView(page);
    }

    void addToggle(LinearLayout row,String label,boolean checked,int index) {
        CheckBox cb = new CheckBox(this);
        cb.setText(label); cb.setTextColor(Color.WHITE); cb.setTextSize(12);
        cb.setButtonTintList(android.content.res.ColorStateList.valueOf(Color.rgb(80,190,160)));
        cb.setChecked(checked);
        cb.setOnCheckedChangeListener((v,on)->table.setLayer(index,on));
        row.addView(cb,new LinearLayout.LayoutParams(0,dp(42),1));
    }
    int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}

    static class AimTable extends View {
        Paint p=new Paint(3);
        float cueX=.30f,cueY=.55f,objX=.64f,objY=.43f;
        boolean[] layers={true,true,true,false};
        int dragging=0;
        float left,top,right,bottom,scale;
        AimTable(Context c){super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        void setLayer(int i,boolean v){layers[i]=v;invalidate();}
        void reset(){cueX=.30f;cueY=.55f;objX=.64f;objY=.43f;invalidate();}
        void line(Canvas c,float x1,float y1,float x2,float y2,int color,float width,boolean dash){
            p.setColor(color);p.setStrokeWidth(width);p.setStyle(Paint.Style.STROKE);
            p.setPathEffect(dash?new DashPathEffect(new float[]{12,9},0):null);
            c.drawLine(x1,y1,x2,y2,p);p.setPathEffect(null);p.setStyle(Paint.Style.FILL);
        }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            float w=getWidth(),h=getHeight();
            left=dp(8); top=dp(18); right=w-dp(8); bottom=h-dp(18);
            float tw=right-left, th=bottom-top;
            p.setColor(Color.rgb(27,91,68)); c.drawRoundRect(left-dp(9),top-dp(9),right+dp(9),bottom+dp(9),dp(18),dp(18),p);
            p.setColor(Color.rgb(171,111,62)); c.drawRoundRect(left,top,right,bottom,dp(8),dp(8),p);
            p.setColor(Color.rgb(8,45,37)); c.drawRoundRect(left-dp(7),top-dp(7),right+dp(7),bottom+dp(7),dp(14),dp(14),p);
            p.setColor(Color.rgb(171,111,62)); c.drawRoundRect(left,top,right,bottom,dp(7),dp(7),p);
            float r=Math.min(tw,th)*.026f;
            // pockets
            p.setColor(Color.rgb(8,18,20));
            float[][] holes={{left,top},{(left+right)/2,top},{right,top},{left,bottom},{(left+right)/2,bottom},{right,bottom}};
            for(float[] a:holes)c.drawCircle(a[0],a[1],r*1.65f,p);

            float cx=left+cueX*tw, cy=top+cueY*th, ox=left+objX*tw, oy=top+objY*th;
            float dx=ox-cx,dy=oy-cy,dist=(float)Math.hypot(dx,dy);
            float ux=dx/(dist==0?1:dist),uy=dy/(dist==0?1:dist);
            float cr=r*1.04f;
            if(layers[0]) line(c,cx,cy,ox-ux*cr,oy-uy*cr,Color.WHITE,dp(1.3f),false);
            if(layers[1]) line(c,cx,cy,cx-ux*tw*.45f,cy-uy*th*.45f,Color.rgb(80,220,255),dp(1.2f),true);
            if(layers[2]){
                float nx=-uy,ny=ux;
                line(c,ox,oy,ox+nx*tw*.24f,oy+ny*th*.24f,Color.rgb(255,218,95),dp(1.4f),false);
                line(c,ox,oy,ox-nx*tw*.24f,oy-ny*th*.24f,Color.rgb(255,218,95),dp(1.4f),false);
            }
            if(layers[3]){
                line(c,ox,oy,ox+ux*tw*.23f,oy+uy*th*.23f,Color.rgb(255,130,110),dp(1.1f),true);
            }
            // object ball and cue ball
            p.setColor(Color.rgb(245,245,240));c.drawCircle(ox,oy,cr,p);
            p.setColor(Color.rgb(30,35,42));p.setTextSize(cr);p.setTextAlign(Paint.Align.CENTER);c.drawText("1",ox,oy+cr*.35f,p);
            p.setColor(Color.WHITE);c.drawCircle(cx,cy,cr,p);
            p.setColor(Color.rgb(185,195,205));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1));c.drawCircle(cx,cy,cr,p);p.setStyle(Paint.Style.FILL);
            p.setColor(Color.WHITE);p.setTextSize(dp(11));p.setTextAlign(Paint.Align.LEFT);c.drawText("BI CÁI",left,top-dp(7),p);
            p.setColor(Color.rgb(255,225,150));c.drawText("BI MỤC TIÊU",right-dp(100),bottom+dp(15),p);
        }
        float dp(float x){return x*getResources().getDisplayMetrics().density;}
        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            float x=e.getX(),y=e.getY(),tw=right-left,th=bottom-top;
            if(e.getAction()==MotionEvent.ACTION_DOWN){
                float cx=left+cueX*tw,cy=top+cueY*th,ox=left+objX*tw,oy=top+objY*th;
                dragging=Math.hypot(x-cx,y-cy)<Math.hypot(x-ox,y-oy)?1:2; return true;
            }
            if(e.getAction()==MotionEvent.ACTION_MOVE){
                float nx=Math.max(.04f,Math.min(.96f,(x-left)/tw));
                float ny=Math.max(.05f,Math.min(.95f,(y-top)/th));
                if(dragging==1){cueX=nx;cueY=ny;} else {objX=nx;objY=ny;}
                invalidate();return true;
            }
            if(e.getAction()==MotionEvent.ACTION_UP){dragging=0;return true;}
            return true;
        }
    }
}
